import { db } from "@/db";
import { sql } from "drizzle-orm";
import { logger } from "@/lib/logger";

export const dynamic = "force-dynamic";

const startTime = Date.now();

export async function GET() {
  const requestId = Math.random().toString(36).substring(2, 10);
  const start = Date.now();
  logger.info("Health check started", { requestId });

  const checks: { name: string; status: "ok" | "fail"; latencyMs?: number; error?: string }[] = [];

  // Database check
  const dbStart = Date.now();
  try {
    await db.execute(sql`SELECT 1`);
    checks.push({ name: "database", status: "ok", latencyMs: Date.now() - dbStart });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Unknown DB error";
    logger.error("Database health check failed", { requestId, error: msg });
    checks.push({ name: "database", status: "fail", latencyMs: Date.now() - dbStart, error: msg });
  }

  // Memory check
  const mem = process.memoryUsage();
  const memOk = mem.heapUsed < 500 * 1024 * 1024; // 500MB threshold
  checks.push({ name: "memory", status: memOk ? "ok" : "fail" });

  const allOk = checks.every((c) => c.status === "ok");
  const duration = Date.now() - start;

  const response = {
    status: allOk ? "healthy" : "degraded",
    timestamp: new Date().toISOString(),
    uptime: Math.floor((Date.now() - startTime) / 1000),
    version: "1.0.0",
    environment: process.env.NODE_ENV,
    requestId,
    checks,
    metrics: {
      heapUsedMb: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotalMb: Math.round(mem.heapTotal / 1024 / 1024),
      rssMb: Math.round(mem.rss / 1024 / 1024),
      responseTimeMs: duration,
    },
  };

  logger.request("GET", "/api/health", allOk ? 200 : 503, duration, { requestId, checks });

  return Response.json(response, {
    status: allOk ? 200 : 503,
    headers: {
      "Cache-Control": "no-store",
      "X-Request-Id": requestId,
    },
  });
}
