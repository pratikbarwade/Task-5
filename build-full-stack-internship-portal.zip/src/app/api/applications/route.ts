import { db } from "@/db";
import { applications, internships } from "@/db/schema";
import { logger, generateRequestId } from "@/lib/logger";
import { applicationSchema } from "@/lib/validators";
import { rateLimit } from "@/lib/rateLimit";
import { eq, desc, and, ilike } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const requestId = generateRequestId();
  const start = Date.now();
  const url = new URL(req.url);
  const email = url.searchParams.get("email")?.toLowerCase().trim();
  const internshipId = url.searchParams.get("internshipId");
  const status = url.searchParams.get("status");

  try {
    let query = db.select().from(applications).$dynamic();

    const conditions: any[] = [];
    if (email) conditions.push(ilike(applications.email, email));
    if (internshipId) conditions.push(eq(applications.internshipId, internshipId));
    if (status) conditions.push(eq(applications.status, status));

    if (conditions.length) {
      query = query.where(conditions.length === 1 ? conditions[0] : and(...conditions));
    }

    const data = await query.orderBy(desc(applications.appliedAt)).limit(100);

    // Enrich with internship titles if needed
    const enriched = await Promise.all(
      data.map(async (app) => {
        const [intern] = await db.select({ title: internships.title, company: internships.company }).from(internships).where(eq(internships.id, app.internshipId)).limit(1);
        return { ...app, internship: intern || null };
      })
    );

    logger.info("Applications listed", { requestId, count: enriched.length, email });
    logger.request("GET", "/api/applications", 200, Date.now() - start, { requestId });

    return Response.json({ data: enriched }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to list applications", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const requestId = generateRequestId();
  const start = Date.now();
  const ip = req.headers.get("x-forwarded-for") || "anonymous";
  const rl = rateLimit(`applications:create:${ip}`);
  if (!rl.allowed) {
    logger.warn("Rate limit exceeded for application", { requestId, ip });
    return Response.json({ error: "Too many requests. Please try again later." }, { status: 429 });
  }

  try {
    const body = await req.json();
    const parsed = applicationSchema.safeParse(body);

    if (!parsed.success) {
      logger.warn("Invalid application payload", { requestId, errors: parsed.error.flatten() });
      return Response.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
    }

    const data = parsed.data;

    // Check internship exists and active
    const [internship] = await db.select().from(internships).where(eq(internships.id, data.internshipId)).limit(1);
    if (!internship) {
      return Response.json({ error: "Internship not found" }, { status: 404 });
    }
    if (!internship.isActive) {
      return Response.json({ error: "This internship is no longer accepting applications" }, { status: 400 });
    }

    // Prevent duplicate application by same email for same internship
    const existing = await db
      .select()
      .from(applications)
      .where(and(eq(applications.internshipId, data.internshipId), eq(applications.email, data.email)))
      .limit(1);

    if (existing.length > 0) {
      return Response.json({ error: "You have already applied to this internship" }, { status: 409 });
    }

    const [created] = await db
      .insert(applications)
      .values({
        internshipId: data.internshipId,
        fullName: data.fullName,
        email: data.email.toLowerCase(),
        phone: data.phone || null,
        university: data.university || null,
        graduationYear: data.graduationYear || null,
        resumeUrl: data.resumeUrl || null,
        coverLetter: data.coverLetter,
        portfolioUrl: data.portfolioUrl || null,
        linkedinUrl: data.linkedinUrl || null,
      })
      .returning();

    // Increment applicants count
    await db
      .update(internships)
      .set({ applicantsCount: (internship.applicantsCount || 0) + 1, updatedAt: new Date() })
      .where(eq(internships.id, data.internshipId));

    logger.info("Application created", { requestId, applicationId: created.id, internshipId: data.internshipId, email: data.email });
    logger.request("POST", "/api/applications", 201, Date.now() - start, { requestId });

    return Response.json({ data: created, message: "Application submitted successfully" }, { status: 201, headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to create application", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
