import { db } from "@/db";
import { applications } from "@/db/schema";
import { logger, generateRequestId } from "@/lib/logger";
import { updateApplicationStatusSchema } from "@/lib/validators";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const requestId = generateRequestId();
  const start = Date.now();

  try {
    const body = await req.json();
    const parsed = updateApplicationStatusSchema.safeParse(body);

    if (!parsed.success) {
      return Response.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
    }

    const [updated] = await db
      .update(applications)
      .set({ status: parsed.data.status, updatedAt: new Date() })
      .where(eq(applications.id, id))
      .returning();

    if (!updated) {
      return Response.json({ error: "Application not found" }, { status: 404 });
    }

    logger.info("Application status updated", { requestId, applicationId: id, status: parsed.data.status });
    logger.request("PATCH", `/api/applications/${id}`, 200, Date.now() - start, { requestId });

    return Response.json({ data: updated }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to update application", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const requestId = generateRequestId();

  try {
    const [deleted] = await db.delete(applications).where(eq(applications.id, id)).returning();
    if (!deleted) return Response.json({ error: "Application not found" }, { status: 404 });

    logger.info("Application deleted", { requestId, applicationId: id });
    return Response.json({ message: "Application deleted" }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to delete application", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
