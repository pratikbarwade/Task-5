import { db } from "@/db";
import { internships, applications } from "@/db/schema";
import { logger, generateRequestId } from "@/lib/logger";
import { internshipSchema } from "@/lib/validators";
import { rateLimit } from "@/lib/rateLimit";
import { eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const requestId = generateRequestId();
  const start = Date.now();

  try {
    const [internship] = await db.select().from(internships).where(eq(internships.id, id)).limit(1);

    if (!internship) {
      logger.warn("Internship not found", { requestId, internshipId: id });
      return Response.json({ error: "Internship not found" }, { status: 404 });
    }

    // Increment view? Not storing, but log
    logger.info("Internship fetched", { requestId, internshipId: id });
    logger.request("GET", `/api/internships/${id}`, 200, Date.now() - start, { requestId });

    return Response.json({ data: internship }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to fetch internship", { requestId, internshipId: id, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const requestId = generateRequestId();
  const start = Date.now();
  const ip = req.headers.get("x-forwarded-for") || "anonymous";
  const rl = rateLimit(`internships:update:${ip}`);
  if (!rl.allowed) return Response.json({ error: "Too many requests" }, { status: 429 });

  try {
    const body = await req.json();
    const parsed = internshipSchema.partial().safeParse(body);
    if (!parsed.success) {
      return Response.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
    }

    const data = parsed.data;

    const updateData: any = { ...data, updatedAt: new Date() };
    if (data.applicationDeadline) updateData.applicationDeadline = new Date(data.applicationDeadline);
    if (data.companyLogo === "") updateData.companyLogo = null;
    if (data.applicationUrl === "") updateData.applicationUrl = null;

    const [updated] = await db.update(internships).set(updateData).where(eq(internships.id, id)).returning();

    if (!updated) {
      return Response.json({ error: "Internship not found" }, { status: 404 });
    }

    logger.info("Internship updated", { requestId, internshipId: id });
    logger.request("PUT", `/api/internships/${id}`, 200, Date.now() - start, { requestId });

    return Response.json({ data: updated }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to update internship", { requestId, internshipId: id, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const requestId = generateRequestId();
  const start = Date.now();

  try {
    const [deleted] = await db.delete(internships).where(eq(internships.id, id)).returning();

    if (!deleted) {
      return Response.json({ error: "Internship not found" }, { status: 404 });
    }

    logger.info("Internship deleted", { requestId, internshipId: id });
    logger.request("DELETE", `/api/internships/${id}`, 200, Date.now() - start, { requestId });

    return Response.json({ message: "Internship deleted", data: deleted }, { headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to delete internship", { requestId, internshipId: id, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
