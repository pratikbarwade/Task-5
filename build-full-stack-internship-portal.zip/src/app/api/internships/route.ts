import { db } from "@/db";
import { internships } from "@/db/schema";
import { logger, generateRequestId } from "@/lib/logger";
import { internshipSchema } from "@/lib/validators";
import { rateLimit } from "@/lib/rateLimit";
import { eq, ilike, and, or, desc, sql, gte, lte } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const requestId = generateRequestId();
  const start = Date.now();
  const url = new URL(req.url);
  const ip = req.headers.get("x-forwarded-for") || "anonymous";
  const rl = rateLimit(`internships:list:${ip}`);
  if (!rl.allowed) {
    logger.warn("Rate limit exceeded", { requestId, path: "/api/internships", ip });
    return Response.json({ error: "Too many requests" }, { status: 429, headers: { "Retry-After": Math.ceil(rl.resetIn / 1000).toString() } });
  }

  try {
    const search = url.searchParams.get("search")?.trim() || "";
    const location = url.searchParams.get("location")?.trim() || "";
    const workType = url.searchParams.get("workType") || "";
    const category = url.searchParams.get("category") || "";
    const experience = url.searchParams.get("experience") || "";
    const page = Math.max(1, parseInt(url.searchParams.get("page") || "1", 10));
    const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get("limit") || "12", 10)));
    const sort = url.searchParams.get("sort") || "newest";
    const minStipend = url.searchParams.get("minStipend") ? parseInt(url.searchParams.get("minStipend")!, 10) : undefined;
    const isActiveParam = url.searchParams.get("isActive");

    const conditions: any[] = [];

    if (isActiveParam !== "false") {
      conditions.push(eq(internships.isActive, true));
    }

    if (search) {
      conditions.push(
        or(
          ilike(internships.title, `%${search}%`),
          ilike(internships.company, `%${search}%`),
          ilike(internships.description, `%${search}%`)
        )
      );
    }

    if (location) {
      conditions.push(ilike(internships.location, `%${location}%`));
    }

    if (workType) {
      conditions.push(eq(internships.workType, workType));
    }

    if (category) {
      conditions.push(eq(internships.category, category));
    }

    if (experience) {
      conditions.push(eq(internships.experienceLevel, experience));
    }

    if (minStipend !== undefined && !isNaN(minStipend)) {
      conditions.push(gte(internships.stipendMax, minStipend));
    }

    const whereClause = conditions.length ? and(...conditions) : undefined;

    const orderBy =
      sort === "stipend_high"
        ? desc(internships.stipendMax)
        : sort === "stipend_low"
        ? internships.stipendMin
        : sort === "deadline"
        ? internships.applicationDeadline
        : desc(internships.postedAt);

    const offset = (page - 1) * limit;

    const [data, totalResult] = await Promise.all([
      db
        .select()
        .from(internships)
        .where(whereClause)
        .orderBy(orderBy)
        .limit(limit)
        .offset(offset),
      db
        .select({ count: sql<number>`count(*)` })
        .from(internships)
        .where(whereClause),
    ]);

    const total = Number(totalResult[0]?.count || 0);
    const totalPages = Math.ceil(total / limit);

    logger.info("Internships listed", { requestId, count: data.length, page, search, category });
    logger.request("GET", "/api/internships", 200, Date.now() - start, { requestId });

    return Response.json(
      {
        data,
        pagination: { page, limit, total, totalPages, hasNext: page < totalPages, hasPrev: page > 1 },
      },
      {
        headers: {
          "X-Request-Id": requestId,
          "Cache-Control": "public, s-maxage=30, stale-while-revalidate=60",
        },
      }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to list internships", { requestId, error: message });
    logger.request("GET", "/api/internships", 500, Date.now() - start, { requestId });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const requestId = generateRequestId();
  const start = Date.now();
  const ip = req.headers.get("x-forwarded-for") || "anonymous";
  const rl = rateLimit(`internships:create:${ip}`);
  if (!rl.allowed) {
    return Response.json({ error: "Too many requests" }, { status: 429 });
  }

  try {
    const body = await req.json();
    const parsed = internshipSchema.safeParse(body);

    if (!parsed.success) {
      logger.warn("Invalid internship payload", { requestId, errors: parsed.error.flatten() });
      return Response.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
    }

    const data = parsed.data;

    const deadline = data.applicationDeadline ? new Date(data.applicationDeadline) : null;

    const [created] = await db
      .insert(internships)
      .values({
        title: data.title,
        company: data.company,
        companyLogo: data.companyLogo || null,
        location: data.location,
        workType: data.workType,
        category: data.category,
        employmentType: data.employmentType,
        description: data.description,
        responsibilities: data.responsibilities || null,
        requirements: data.requirements || null,
        skills: data.skills,
        stipendMin: data.stipendMin,
        stipendMax: data.stipendMax,
        stipendCurrency: data.stipendCurrency,
        durationMonths: data.durationMonths,
        applicationDeadline: deadline,
        isActive: data.isActive,
        tags: data.tags,
        experienceLevel: data.experienceLevel,
        perks: data.perks || null,
        applicationUrl: data.applicationUrl || null,
      })
      .returning();

    logger.info("Internship created", { requestId, internshipId: created.id, title: created.title });
    logger.request("POST", "/api/internships", 201, Date.now() - start, { requestId });

    return Response.json({ data: created }, { status: 201, headers: { "X-Request-Id": requestId } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to create internship", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
