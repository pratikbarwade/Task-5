import { db } from "@/db";
import { internships, applications } from "@/db/schema";
import { sql, eq, count } from "drizzle-orm";
import { logger, generateRequestId } from "@/lib/logger";

export const dynamic = "force-dynamic";

export async function GET() {
  const requestId = generateRequestId();
  const start = Date.now();
  try {
    const [internshipStats] = await db
      .select({
        total: sql<number>`count(*)`,
        active: sql<number>`count(*) filter (where is_active = true)`,
        remote: sql<number>`count(*) filter (where work_type = 'remote')`,
        totalApplicants: sql<number>`coalesce(sum(applicants_count),0)`,
      })
      .from(internships);

    const [appStats] = await db
      .select({
        total: sql<number>`count(*)`,
        pending: sql<number>`count(*) filter (where status = 'pending')`,
        shortlisted: sql<number>`count(*) filter (where status = 'shortlisted')`,
        accepted: sql<number>`count(*) filter (where status = 'accepted')`,
      })
      .from(applications);

    const categoryStats = await db
      .select({ category: internships.category, count: sql<number>`count(*)` })
      .from(internships)
      .where(eq(internships.isActive, true))
      .groupBy(internships.category);

    const response = {
      internships: {
        total: Number(internshipStats.total || 0),
        active: Number(internshipStats.active || 0),
        remote: Number(internshipStats.remote || 0),
        totalApplicants: Number(internshipStats.totalApplicants || 0),
      },
      applications: {
        total: Number(appStats.total || 0),
        pending: Number(appStats.pending || 0),
        shortlisted: Number(appStats.shortlisted || 0),
        accepted: Number(appStats.accepted || 0),
      },
      categories: categoryStats.map((c) => ({ category: c.category, count: Number(c.count) })),
    };

    logger.request("GET", "/api/stats", 200, Date.now() - start, { requestId });
    return Response.json(response, { headers: { "X-Request-Id": requestId, "Cache-Control": "public, s-maxage=60" } });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    logger.error("Failed to fetch stats", { requestId, error: message });
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
