import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-2xl">🔍</div>
      <h1 className="mt-6 text-3xl font-bold tracking-tight">Page not found</h1>
      <p className="mt-3 text-sm text-slate-600">The page you&apos;re looking for doesn&apos;t exist or was moved. Check URL or browse internships.</p>
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/" className="rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white">Go home</Link>
        <Link href="/internships" className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-medium">Browse internships</Link>
      </div>
    </div>
  );
}
