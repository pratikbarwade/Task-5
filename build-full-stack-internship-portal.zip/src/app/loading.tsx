export default function Loading() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="animate-pulse space-y-6">
        <div className="h-8 w-48 rounded bg-slate-200"></div>
        <div className="h-24 rounded-2xl bg-slate-200"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-64 rounded-2xl bg-slate-200"></div>
          <div className="h-64 rounded-2xl bg-slate-200"></div>
          <div className="h-64 rounded-2xl bg-slate-200"></div>
        </div>
      </div>
    </div>
  );
}
