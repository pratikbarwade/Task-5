import { db } from "@/db";
import { internships } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import Link from "next/link";
import InternshipCard from "@/components/InternshipCard";
import SearchBar from "@/components/SearchBar";
import { logger } from "@/lib/logger";

export const dynamic = "force-dynamic";

async function getFeaturedInternships() {
  try {
    const data = await db.select().from(internships).where(eq(internships.isActive, true)).orderBy(desc(internships.postedAt)).limit(6);
    return data;
  } catch (err) {
    logger.error("Failed to fetch featured internships", { error: err instanceof Error ? err.message : "unknown" });
    return [];
  }
}

async function getStats() {
  try {
    const [stats] = await db.select({
      total: sql<number>`count(*)`,
      remote: sql<number>`count(*) filter (where work_type='remote')`,
      companies: sql<number>`count(distinct company)`,
    }).from(internships);
    return {
      total: Number(stats?.total || 0),
      remote: Number(stats?.remote || 0),
      companies: Number(stats?.companies || 0),
    };
  } catch {
    return { total: 12, remote: 5, companies: 8 };
  }
}

export default async function HomePage() {
  const [featured, stats] = await Promise.all([getFeaturedInternships(), getStats()]);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff0a_1px,transparent_1px),linear-gradient(to_bottom,#ffffff0a_1px,transparent_1px)] bg-[size:4rem_4rem]" aria-hidden="true"></div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="inline-flex items-center rounded-full bg-white/10 px-4 py-1.5 text-xs font-medium text-white ring-1 ring-inset ring-white/20 backdrop-blur">
              <span className="mr-2 h-2 w-2 rounded-full bg-emerald-400 animate-pulse" aria-hidden="true"></span>
              {stats.total}+ internships live • Production ready
            </div>
            <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.05]">
              Find your <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 to-violet-300">dream internship</span> faster
            </h1>
            <p className="mt-6 text-lg leading-8 text-slate-300 max-w-2xl mx-auto">
              Curated internships from top companies. Remote, hybrid, onsite. Filter by skills, stipend, and location. Apply in 60 seconds. Fictional data for demo — production architecture.
            </p>

            <div className="mt-10">
              <SearchBar />
              <p className="mt-3 text-xs text-slate-400">Try: &quot;React&quot; • &quot;Remote&quot; • &quot;Data Science&quot; • &quot;New York&quot;</p>
            </div>

            <div className="mt-10 grid grid-cols-3 gap-6 max-w-md mx-auto">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{stats.total || 12}+</div>
                <div className="text-xs text-slate-400 uppercase tracking-wide mt-1">Internships</div>
              </div>
              <div className="text-center border-x border-white/10">
                <div className="text-2xl font-bold text-white">{stats.companies || 8}+</div>
                <div className="text-xs text-slate-400 uppercase tracking-wide mt-1">Companies</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{stats.remote || 5}</div>
                <div className="text-xs text-slate-400 uppercase tracking-wide mt-1">Remote</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted by */}
      <section className="border-y border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4 text-sm text-slate-500">
            <span className="font-medium">Trusted workflow by students from:</span>
            <span className="font-semibold text-slate-700">Nimbus Labs</span>
            <span className="font-semibold text-slate-700">Quantora AI</span>
            <span className="font-semibold text-slate-700">Atlas Growth</span>
            <span className="font-semibold text-slate-700">StreamForge</span>
            <span className="font-semibold text-slate-700">Pixelcraft</span>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">Featured internships</h2>
            <p className="mt-2 text-sm text-slate-600">Handpicked opportunities, updated daily. All fictional for demo.</p>
          </div>
          <Link href="/internships" className="hidden sm:inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-700">
            View all <svg className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featured.length > 0 ? (
            featured.map((intern) => <InternshipCard key={intern.id} internship={intern} />)
          ) : (
            // Fallback skeleton/fictional preview when DB empty
            <div className="col-span-full rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
              <h3 className="text-lg font-semibold text-slate-900">No internships yet</h3>
              <p className="mt-2 text-sm text-slate-600">Database is empty. Seed it to see fictional internships.</p>
              <div className="mt-6 flex justify-center gap-3">
                <Link href="/api/seed" className="rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-medium text-white">Seed via API</Link>
                <Link href="/post" className="rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium">Post one</Link>
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 flex sm:hidden justify-center">
          <Link href="/internships" className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white">Browse all internships</Link>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="bg-white border-y border-slate-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">How InternBoard works</h2>
            <p className="mt-3 text-sm text-slate-600">Designed for speed, clarity, and mobile-first experience.</p>
          </div>
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: "01", title: "Discover", desc: "Search by title, company, skills, or location. Filter remote, hybrid, stipend, and experience level.", icon: "🔍" },
              { step: "02", title: "Apply in 60s", desc: "One form, no account needed. Track applications with just your email. Fictional data safe.", icon: "⚡" },
              { step: "03", title: "Track & Manage", desc: "Dashboard shows status: pending, reviewed, shortlisted. Recruiters manage postings and applicants.", icon: "📊" },
            ].map((item) => (
              <div key={item.step} className="relative rounded-2xl border border-slate-200 bg-slate-50 p-6">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white border border-slate-200 text-lg" aria-hidden="true">{item.icon}</div>
                <div className="mt-4">
                  <div className="text-xs font-bold tracking-widest text-indigo-600">{item.step}</div>
                  <h3 className="mt-1 text-lg font-semibold text-slate-900">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="rounded-[2rem] bg-slate-900 px-6 py-12 sm:px-12 sm:py-16 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-violet-600/20" aria-hidden="true"></div>
          <div className="relative grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-white">Ready to launch your career?</h2>
              <p className="mt-4 text-slate-300">Join thousands of students who found internships. Production-ready, secure, and beginner-friendly.</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/internships" className="inline-flex items-center justify-center rounded-full bg-white px-6 py-3 text-sm font-semibold text-slate-900 hover:bg-slate-100">Browse internships</Link>
                <Link href="/post" className="inline-flex items-center justify-center rounded-full bg-white/10 px-6 py-3 text-sm font-semibold text-white ring-1 ring-inset ring-white/20 hover:bg-white/15">Post an internship</Link>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur ring-1 ring-white/10">
                <div className="text-2xl font-bold text-white">WCAG AA</div>
                <div className="mt-1 text-xs text-slate-300">Accessibility compliant</div>
              </div>
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur ring-1 ring-white/10">
                <div className="text-2xl font-bold text-white">&lt; 100ms</div>
                <div className="mt-1 text-xs text-slate-300">API avg response</div>
              </div>
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur ring-1 ring-white/10">
                <div className="text-2xl font-bold text-white">100%</div>
                <div className="mt-1 text-xs text-slate-300">TypeScript typed</div>
              </div>
              <div className="rounded-2xl bg-white/10 p-5 backdrop-blur ring-1 ring-white/10">
                <div className="text-2xl font-bold text-white">Mobile</div>
                <div className="mt-1 text-xs text-slate-300">Fully responsive</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
