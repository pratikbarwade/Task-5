import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "InternBoard — Find Your Dream Internship",
    template: "%s | InternBoard",
  },
  description: "Production-ready internship portal. Discover, filter, and apply to top internships from leading companies. Remote, hybrid, and onsite opportunities.",
  keywords: ["internship", "jobs", "students", "career", "remote internships", "tech internships"],
  authors: [{ name: "InternBoard Team" }],
  openGraph: {
    title: "InternBoard — Find Your Dream Internship",
    description: "Discover and apply to top internships from leading companies.",
    type: "website",
    locale: "en_US",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased flex flex-col">
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
        <Header />
        <main id="main-content" className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
