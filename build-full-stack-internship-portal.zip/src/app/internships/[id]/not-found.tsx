import Link from "next/link";

export default function InternshipNotFound() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 text-center">
      <h1 className="text-2xl font-bold">Internship not found</h1>
      <p className="mt-2 text-sm text-slate-600">This internship may have been removed or the link is incorrect. It was fictional for demo anyway.</p>
      <Link href="/internships" className="mt-6 inline-flex rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white">Browse all</Link>
    </div>
  );
}
