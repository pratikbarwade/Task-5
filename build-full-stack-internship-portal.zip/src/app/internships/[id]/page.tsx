import { db } from "@/db";
import { internships, applications } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import Link from "next/link";
import { formatCurrency, formatDate } from "@/lib/utils";
import ApplicationForm from "@/components/ApplicationForm";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

async function getInternship(id: string) {
  const [data] = await db.select().from(internships).where(eq(internships.id, id)).limit(1);
  return data || null;
}

export default async function InternshipDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const internship = await getInternship(id);

  if (!internship) {
    notFound();
  }

  const skills = (internship.skills as string[]) || [];
  const tags = (internship.tags as string[]) || [];

  const [applicantCountResult] = await db.select({ count: sql<number>`count(*)` }).from(applications).where(eq(applications.internshipId, id));
  const realApplicantCount = Number(applicantCountResult?.count || 0);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <nav aria-label="Breadcrumb" className="mb-6">
        <ol className="flex items-center gap-2 text-sm text-slate-500">
          <li><Link href="/" className="hover:text-slate-700">Home</Link></li>
          <li aria-hidden="true">/</li>
          <li><Link href="/internships" className="hover:text-slate-700">Internships</Link></li>
          <li aria-hidden="true">/</li>
          <li className="text-slate-900 font-medium truncate max-w-[200px]">{internship.title}</li>
        </ol>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8">
        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
            <div className="flex items-start gap-4">
              <div className="h-16 w-16 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden">
                {internship.companyLogo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={internship.companyLogo} alt={`${internship.company} logo`} className="h-full w-full object-cover" />
                ) : (
                  <span className="text-xl font-bold text-slate-600">{internship.company.charAt(0)}</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">{internship.title}</h1>
                <p className="mt-2 text-base text-slate-600">{internship.company} • {internship.location} • {internship.workType}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="inline-flex items-center rounded-full bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-700 ring-1 ring-inset ring-indigo-600/20">{internship.category}</span>
                  <span className="inline-flex items-center rounded-full bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700 ring-1 ring-inset ring-slate-600/10">{internship.experienceLevel} level</span>
                  <span className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20">{internship.durationMonths} months</span>
                  {internship.isActive ? (
                    <span className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">● Active</span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-red-50 px-3 py-1 text-xs font-medium text-red-700">Closed</span>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-6 border-y border-slate-100 py-6">
              <div>
                <div className="text-xs uppercase tracking-wide text-slate-500">Stipend</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">{formatCurrency(internship.stipendMin || 0)} - {formatCurrency(internship.stipendMax || 0)} <span className="text-xs font-normal text-slate-500">/{internship.stipendCurrency} / month</span></div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-slate-500">Applicants</div>
                <div className="mt-1 text-lg font-semibold text-slate-900">{realApplicantCount} <span className="text-xs font-normal text-slate-500">applied</span></div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-slate-500">Deadline</div>
                <div className="mt-1 text-sm font-semibold text-slate-900">{internship.applicationDeadline ? formatDate(internship.applicationDeadline) : "Rolling"}</div>
              </div>
            </div>

            <div className="mt-8 space-y-8">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">About the role</h2>
                <p className="mt-3 text-sm leading-7 text-slate-700 whitespace-pre-wrap">{internship.description}</p>
              </div>

              {internship.responsibilities && (
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Responsibilities</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-700 whitespace-pre-wrap">{internship.responsibilities}</p>
                </div>
              )}

              {internship.requirements && (
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Requirements</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-700 whitespace-pre-wrap">{internship.requirements}</p>
                </div>
              )}

              {skills.length > 0 && (
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Skills</h3>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {skills.map((skill) => (
                      <span key={skill} className="inline-flex items-center rounded-full bg-slate-900 px-3 py-1.5 text-xs font-medium text-white">{skill}</span>
                    ))}
                  </div>
                </div>
              )}

              {internship.perks && (
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Perks & Benefits</h3>
                  <p className="mt-3 text-sm leading-7 text-slate-700">{internship.perks}</p>
                </div>
              )}
            </div>
          </div>

          <div id="apply">
            <ApplicationForm internshipId={internship.id} internshipTitle={internship.title} />
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 sticky top-24">
            <h3 className="text-sm font-semibold text-slate-900">Quick Apply</h3>
            <p className="mt-2 text-xs text-slate-600">Complete form in 60 seconds. No account needed.</p>
            <a href="#apply" className="mt-4 flex w-full items-center justify-center rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700">Apply Now</a>
            <div className="mt-6 space-y-3 text-xs text-slate-600">
              <div className="flex justify-between"><span>Posted</span><span className="font-medium text-slate-900">{internship.postedAt ? formatDate(internship.postedAt) : "Recently"}</span></div>
              <div className="flex justify-between"><span>Location</span><span className="font-medium text-slate-900">{internship.location}</span></div>
              <div className="flex justify-between"><span>Work Type</span><span className="font-medium text-slate-900 capitalize">{internship.workType}</span></div>
              <div className="flex justify-between"><span>Duration</span><span className="font-medium text-slate-900">{internship.durationMonths} months</span></div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
              <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wide">Share</h4>
              <div className="mt-3 flex gap-2">
                <button onClick={() => { if (typeof navigator !== 'undefined' && navigator.clipboard) navigator.clipboard.writeText(window.location.href) }} className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium hover:bg-slate-50">Copy link</button>
                <Link href="/internships" className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-center hover:bg-slate-50">Browse more</Link>
              </div>
            </div>

            <div className="mt-6 rounded-xl bg-amber-50 border border-amber-200 p-3">
              <p className="text-xs text-amber-800"><strong>Fictional Demo:</strong> This internship is fictional. No real hiring. Use dummy data when applying.</p>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-900 p-6 text-white">
            <h3 className="text-sm font-semibold">Need help?</h3>
            <p className="mt-2 text-xs text-slate-300 leading-5">Check dashboard for application status, or post your own internship if you&apos;re a recruiter.</p>
            <div className="mt-4 flex gap-2">
              <Link href="/dashboard" className="flex-1 rounded-xl bg-white px-3 py-2 text-xs font-semibold text-slate-900 text-center">Dashboard</Link>
              <Link href="/post" className="flex-1 rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-white ring-1 ring-inset ring-white/20 text-center">Post role</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
