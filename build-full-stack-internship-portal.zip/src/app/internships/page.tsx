import { db } from "@/db";
import { internships } from "@/db/schema";
import { and, or, ilike, eq, desc, sql, gte } from "drizzle-orm";
import InternshipCard from "@/components/InternshipCard";
import Filters from "@/components/Filters";
import SearchBar from "@/components/SearchBar";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface SearchParams {
  search?: string;
  location?: string;
  workType?: string;
  category?: string;
  experience?: string;
  page?: string;
  limit?: string;
  sort?: string;
  minStipend?: string;
}

async function getInternships(params: SearchParams) {
  const search = params.search?.trim() || "";
  const location = params.location?.trim() || "";
  const workType = params.workType || "";
  const category = params.category || "";
  const experience = params.experience || "";
  const page = Math.max(1, parseInt(params.page || "1", 10));
  const limit = Math.min(50, Math.max(1, parseInt(params.limit || "12", 10)));
  const sort = params.sort || "newest";
  const minStipend = params.minStipend ? parseInt(params.minStipend, 10) : undefined;

  const conditions: any[] = [eq(internships.isActive, true)];

  if (search) {
    conditions.push(
      or(
        ilike(internships.title, `%${search}%`),
        ilike(internships.company, `%${search}%`),
        ilike(internships.description, `%${search}%`)
      )
    );
  }
  if (location) conditions.push(ilike(internships.location, `%${location}%`));
  if (workType) conditions.push(eq(internships.workType, workType));
  if (category) conditions.push(eq(internships.category, category));
  if (experience) conditions.push(eq(internships.experienceLevel, experience));
  if (minStipend !== undefined && !isNaN(minStipend)) conditions.push(gte(internships.stipendMax, minStipend));

  const whereClause = conditions.length ? and(...conditions) : undefined;

  const orderBy =
    sort === "stipend_high"
      ? desc(internships.stipendMax)
      : sort === "stipend_low"
      ? internships.stipendMin
      : sort === "deadline"
      ? internships.applicationDeadline
      : desc(internships.postedAt);

  const offset = (page - 1) * limit;

  const [data, totalResult] = await Promise.all([
    db.select().from(internships).where(whereClause).orderBy(orderBy).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(internships).where(whereClause),
  ]);

  const total = Number(totalResult[0]?.count || 0);
  const totalPages = Math.ceil(total / limit);

  return { data, total, totalPages, page, limit };
}

export default async function InternshipsPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const params = await searchParams;
  const { data, total, totalPages, page } = await getInternships(params);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Browse Internships</h1>
        <p className="text-sm text-slate-600">Showing {total} opportunities • Page {page} of {totalPages || 1} • Fictional data</p>
      </div>

      <div className="mt-6">
        <SearchBar initialSearch={params.search} initialLocation={params.location} />
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-8">
        <aside className="lg:sticky lg:top-24 self-start">
          <Filters />
        </aside>

        <div>
          {data.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
                <svg className="h-6 w-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47-.881-6.08-2.33" /></svg>
              </div>
              <h3 className="mt-4 text-lg font-semibold text-slate-900">No internships found</h3>
              <p className="mt-2 text-sm text-slate-600">Try adjusting filters or search. Or seed the database if empty.</p>
              <div className="mt-6 flex justify-center gap-3">
                <Link href="/internships" className="rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-medium text-white">Clear filters</Link>
                <Link href="/post" className="rounded-xl border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium">Post internship</Link>
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {data.map((intern) => (
                  <InternshipCard key={intern.id} internship={intern} />
                ))}
              </div>

              {totalPages > 1 && (
                <nav aria-label="Pagination" className="mt-10 flex items-center justify-center gap-2">
                  <Link
                    href={`/internships?${new URLSearchParams({ ...params, page: String(Math.max(1, page - 1)) } as any).toString()}`}
                    aria-disabled={page <= 1}
                    className={`inline-flex items-center rounded-xl border px-4 py-2 text-sm font-medium ${page <= 1 ? "border-slate-200 bg-slate-50 text-slate-400 pointer-events-none" : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"}`}
                  >
                    Previous
                  </Link>
                  <span className="px-4 py-2 text-sm text-slate-600">
                    Page {page} of {totalPages}
                  </span>
                  <Link
                    href={`/internships?${new URLSearchParams({ ...params, page: String(Math.min(totalPages, page + 1)) } as any).toString()}`}
                    aria-disabled={page >= totalPages}
                    className={`inline-flex items-center rounded-xl border px-4 py-2 text-sm font-medium ${page >= totalPages ? "border-slate-200 bg-slate-50 text-slate-400 pointer-events-none" : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"}`}
                  >
                    Next
                  </Link>
                </nav>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
