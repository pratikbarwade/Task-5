"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/utils";

export default function PostInternshipPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [form, setForm] = useState({
    title: "",
    company: "",
    companyLogo: "",
    location: "",
    workType: "remote",
    category: "Software Engineering",
    employmentType: "internship",
    description: "",
    responsibilities: "",
    requirements: "",
    skills: "",
    stipendMin: "",
    stipendMax: "",
    stipendCurrency: "USD",
    durationMonths: "3",
    applicationDeadline: "",
    experienceLevel: "entry",
    perks: "",
    tags: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    if (!form.title || !form.company || !form.location || !form.description) {
      setError("Please fill required fields: title, company, location, description");
      setLoading(false);
      return;
    }

    try {
      const payload = {
        title: form.title,
        company: form.company,
        companyLogo: form.companyLogo || undefined,
        location: form.location,
        workType: form.workType,
        category: form.category,
        employmentType: form.employmentType,
        description: form.description,
        responsibilities: form.responsibilities || undefined,
        requirements: form.requirements || undefined,
        skills: form.skills.split(",").map((s) => s.trim()).filter(Boolean),
        stipendMin: form.stipendMin ? parseInt(form.stipendMin, 10) : 0,
        stipendMax: form.stipendMax ? parseInt(form.stipendMax, 10) : 0,
        stipendCurrency: form.stipendCurrency,
        durationMonths: parseInt(form.durationMonths, 10) || 3,
        applicationDeadline: form.applicationDeadline || undefined,
        tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        experienceLevel: form.experienceLevel,
        perks: form.perks || undefined,
      };

      const res = await fetch("/api/internships", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || JSON.stringify(data.details) || "Failed to create");
      }

      setSuccess("Internship posted successfully!");
      setTimeout(() => router.push(`/internships/${data.data.id}`), 1000);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Post an Internship</h1>
        <p className="mt-2 text-sm text-slate-600">Create a fictional internship listing for demo. All fields support production validation, logging, and security checks.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        {error && <div className="rounded-xl bg-red-50 border border-red-200 p-4 text-sm text-red-700" role="alert">{error}</div>}
        {success && <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-4 text-sm text-emerald-700" role="status">{success}</div>}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label htmlFor="title" className="block text-sm font-medium text-slate-700">Internship Title *</label>
            <input id="title" name="title" required value={form.title} onChange={handleChange} placeholder="Frontend Engineering Intern" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
          </div>

          <div>
            <label htmlFor="company" className="block text-sm font-medium text-slate-700">Company *</label>
            <input id="company" name="company" required value={form.company} onChange={handleChange} placeholder="Nimbus Labs" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="companyLogo" className="block text-sm font-medium text-slate-700">Company Logo URL</label>
            <input id="companyLogo" name="companyLogo" type="url" value={form.companyLogo} onChange={handleChange} placeholder="https://..." className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="location" className="block text-sm font-medium text-slate-700">Location *</label>
            <input id="location" name="location" required value={form.location} onChange={handleChange} placeholder="San Francisco, CA or Remote" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="workType" className="block text-sm font-medium text-slate-700">Work Type</label>
            <select id="workType" name="workType" value={form.workType} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500">
              <option value="remote">Remote</option>
              <option value="hybrid">Hybrid</option>
              <option value="onsite">Onsite</option>
            </select>
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-slate-700">Category</label>
            <select id="category" name="category" value={form.category} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500">
              {CATEGORIES.map((cat) => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>

          <div>
            <label htmlFor="experienceLevel" className="block text-sm font-medium text-slate-700">Experience Level</label>
            <select id="experienceLevel" name="experienceLevel" value={form.experienceLevel} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500">
              <option value="entry">Entry</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>

          <div>
            <label htmlFor="stipendMin" className="block text-sm font-medium text-slate-700">Stipend Min (USD/month)</label>
            <input id="stipendMin" name="stipendMin" type="number" min={0} value={form.stipendMin} onChange={handleChange} placeholder="3000" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="stipendMax" className="block text-sm font-medium text-slate-700">Stipend Max (USD/month)</label>
            <input id="stipendMax" name="stipendMax" type="number" min={0} value={form.stipendMax} onChange={handleChange} placeholder="4500" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="durationMonths" className="block text-sm font-medium text-slate-700">Duration (months)</label>
            <input id="durationMonths" name="durationMonths" type="number" min={1} max={24} value={form.durationMonths} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div>
            <label htmlFor="applicationDeadline" className="block text-sm font-medium text-slate-700">Application Deadline</label>
            <input id="applicationDeadline" name="applicationDeadline" type="date" value={form.applicationDeadline} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="skills" className="block text-sm font-medium text-slate-700">Skills (comma separated)</label>
            <input id="skills" name="skills" value={form.skills} onChange={handleChange} placeholder="React, TypeScript, Tailwind" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>

          <div className="sm:col-span-2">
            <label htmlFor="tags" className="block text-sm font-medium text-slate-700">Tags (comma separated)</label>
            <input id="tags" name="tags" value={form.tags} onChange={handleChange} placeholder="Frontend, Remote, Entry Level" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description *</label>
          <textarea id="description" name="description" required rows={4} value={form.description} onChange={handleChange} placeholder="Describe the internship role, team, and impact..." className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"></textarea>
        </div>

        <div>
          <label htmlFor="responsibilities" className="block text-sm font-medium text-slate-700">Responsibilities</label>
          <textarea id="responsibilities" name="responsibilities" rows={3} value={form.responsibilities} onChange={handleChange} placeholder="• Build features&#10;• Collaborate with team" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"></textarea>
        </div>

        <div>
          <label htmlFor="requirements" className="block text-sm font-medium text-slate-700">Requirements</label>
          <textarea id="requirements" name="requirements" rows={3} value={form.requirements} onChange={handleChange} placeholder="• Pursuing CS degree&#10;• Familiar with React" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500"></textarea>
        </div>

        <div>
          <label htmlFor="perks" className="block text-sm font-medium text-slate-700">Perks & Benefits</label>
          <input id="perks" name="perks" value={form.perks} onChange={handleChange} placeholder="Mentorship, Free lunch, Flexible hours" className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:ring-2 focus:ring-indigo-500" />
        </div>

        <div className="flex gap-3 pt-2">
          <button type="submit" disabled={loading} className="flex-1 sm:flex-none rounded-xl bg-indigo-600 px-8 py-3 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50">{loading ? "Posting..." : "Post Internship"}</button>
          <button type="button" onClick={() => history.back()} className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-medium hover:bg-slate-50">Cancel</button>
        </div>

        <p className="text-xs text-slate-500">Fictional posting only. No real recruitment. Demonstrates validation, rate limiting, and structured logging.</p>
      </form>
    </div>
  );
}
