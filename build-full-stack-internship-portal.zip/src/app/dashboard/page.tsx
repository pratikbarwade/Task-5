"use client";
import { useState, useEffect } from "react";
import Link from "next/link";

interface Application {
  id: string;
  internshipId: string;
  fullName: string;
  email: string;
  status: string;
  appliedAt: string;
  internship?: { title: string; company: string } | null;
}

interface Internship {
  id: string;
  title: string;
  company: string;
  isActive: boolean;
  applicantsCount: number;
  postedAt: string;
}

export default function DashboardPage() {
  const [email, setEmail] = useState("");
  const [applications, setApplications] = useState<Application[]>([]);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"applications" | "manage">("applications");
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const emailParam = params.get("email");
    const stored = localStorage.getItem("lastApplicantEmail");
    if (emailParam) setEmail(emailParam);
    else if (stored) setEmail(stored);
  }, []);

  useEffect(() => {
    fetchStats();
    fetchInternships();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/stats");
      if (res.ok) setStats(await res.json());
    } catch {}
  };

  const fetchInternships = async () => {
    try {
      const res = await fetch("/api/internships?limit=100");
      if (res.ok) {
        const data = await res.json();
        setInternships(data.data || []);
      }
    } catch {}
  };

  const fetchApplications = async (emailToFetch?: string) => {
    const targetEmail = emailToFetch || email;
    if (!targetEmail) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/applications?email=${encodeURIComponent(targetEmail)}`);
      if (res.ok) {
        const data = await res.json();
        setApplications(data.data || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (email && activeTab === "applications") {
      fetchApplications(email);
    }
  }, [activeTab]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchApplications();
    localStorage.setItem("lastApplicantEmail", email);
    const url = new URL(window.location.href);
    url.searchParams.set("email", email);
    window.history.replaceState({}, "", url.toString());
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/applications/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        setApplications((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
      }
    } catch {}
  };

  const deleteInternship = async (id: string) => {
    if (!confirm("Delete this internship? This will also delete its applications.")) return;
    try {
      const res = await fetch(`/api/internships/${id}`, { method: "DELETE" });
      if (res.ok) {
        setInternships((prev) => prev.filter((i) => i.id !== id));
      }
    } catch {}
  };

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-2 text-sm text-slate-600">Track applications, manage postings, view analytics. Fictional demo data.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setActiveTab("applications")} className={`px-4 py-2 rounded-xl text-sm font-medium ${activeTab === "applications" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-700"}`}>My Applications</button>
          <button onClick={() => setActiveTab("manage")} className={`px-4 py-2 rounded-xl text-sm font-medium ${activeTab === "manage" ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-700"}`}>Manage Internships</button>
        </div>
      </div>

      {stats && (
        <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="text-xs uppercase tracking-wide text-slate-500">Total Internships</div>
            <div className="mt-2 text-2xl font-bold">{stats.internships.total}</div>
            <div className="mt-1 text-xs text-slate-500">{stats.internships.active} active</div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="text-xs uppercase tracking-wide text-slate-500">Applications</div>
            <div className="mt-2 text-2xl font-bold">{stats.applications.total}</div>
            <div className="mt-1 text-xs text-slate-500">{stats.applications.pending} pending</div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="text-xs uppercase tracking-wide text-slate-500">Remote Roles</div>
            <div className="mt-2 text-2xl font-bold">{stats.internships.remote}</div>
            <div className="mt-1 text-xs text-slate-500">work from anywhere</div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <div className="text-xs uppercase tracking-wide text-slate-500">Companies</div>
            <div className="mt-2 text-2xl font-bold">{stats.categories?.length || 0}</div>
            <div className="mt-1 text-xs text-slate-500">categories</div>
          </div>
        </div>
      )}

      <div className="mt-8">
        {activeTab === "applications" ? (
          <div className="space-y-6">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3 rounded-2xl border border-slate-200 bg-white p-4">
              <div className="flex-1">
                <label htmlFor="email-search" className="sr-only">Email</label>
                <input id="email-search" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email to view applications" className="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" />
              </div>
              <button type="submit" disabled={loading} className="rounded-xl bg-slate-900 px-6 py-2.5 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50">
                {loading ? "Loading..." : "View Applications"}
              </button>
              <Link href="/internships" className="rounded-xl border border-slate-200 bg-white px-6 py-2.5 text-sm font-medium text-center hover:bg-slate-50">Browse</Link>
            </form>

            {applications.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
                <h3 className="text-lg font-semibold">No applications yet</h3>
                <p className="mt-2 text-sm text-slate-600">{email ? `No applications found for ${email}` : "Enter email above to see your applications, or start applying."}</p>
                <Link href="/internships" className="mt-6 inline-flex rounded-xl bg-indigo-600 px-6 py-2.5 text-sm font-semibold text-white">Find internships</Link>
              </div>
            ) : (
              <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="text-left px-6 py-3 font-medium text-slate-600">Internship</th>
                        <th className="text-left px-6 py-3 font-medium text-slate-600">Applied</th>
                        <th className="text-left px-6 py-3 font-medium text-slate-600">Status</th>
                        <th className="text-left px-6 py-3 font-medium text-slate-600">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {applications.map((app) => (
                        <tr key={app.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4">
                            <div className="font-medium text-slate-900">{app.internship?.title || "Internship"}</div>
                            <div className="text-xs text-slate-500">{app.internship?.company}</div>
                          </td>
                          <td className="px-6 py-4 text-slate-600">{new Date(app.appliedAt).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-medium ${
                              app.status === "pending" ? "bg-amber-50 text-amber-700 ring-1 ring-amber-600/20" :
                              app.status === "shortlisted" ? "bg-blue-50 text-blue-700 ring-1 ring-blue-600/20" :
                              app.status === "accepted" ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-600/20" :
                              app.status === "rejected" ? "bg-red-50 text-red-700 ring-1 ring-red-600/20" :
                              "bg-slate-50 text-slate-700"
                            }`}>
                              {app.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <Link href={`/internships/${app.internshipId}`} className="text-xs font-medium text-indigo-600 hover:text-indigo-700">View role</Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Manage Internships</h2>
              <Link href="/post" className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700">Post new</Link>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="text-left px-6 py-3 font-medium text-slate-600">Role</th>
                      <th className="text-left px-6 py-3 font-medium text-slate-600">Company</th>
                      <th className="text-left px-6 py-3 font-medium text-slate-600">Applicants</th>
                      <th className="text-left px-6 py-3 font-medium text-slate-600">Status</th>
                      <th className="text-left px-6 py-3 font-medium text-slate-600">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {internships.map((intern) => (
                      <tr key={intern.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4 font-medium text-slate-900">{intern.title}</td>
                        <td className="px-6 py-4 text-slate-600">{intern.company}</td>
                        <td className="px-6 py-4">{intern.applicantsCount}</td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex rounded-full px-2.5 py-1 text-xs ${intern.isActive ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{intern.isActive ? "Active" : "Closed"}</span>
                        </td>
                        <td className="px-6 py-4 flex gap-2">
                          <Link href={`/internships/${intern.id}`} className="text-xs font-medium text-indigo-600 hover:text-indigo-700">View</Link>
                          <button onClick={() => deleteInternship(intern.id)} className="text-xs font-medium text-red-600 hover:text-red-700">Delete</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
