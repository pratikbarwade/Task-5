import { pgTable, uuid, varchar, text, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const internships = pgTable("internships", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 255 }).notNull(),
  company: varchar("company", { length: 255 }).notNull(),
  companyLogo: varchar("company_logo", { length: 512 }),
  location: varchar("location", { length: 255 }).notNull(),
  workType: varchar("work_type", { length: 50 }).notNull().default("remote"), // remote | hybrid | onsite
  category: varchar("category", { length: 100 }).notNull(),
  employmentType: varchar("employment_type", { length: 50 }).notNull().default("internship"),
  description: text("description").notNull(),
  responsibilities: text("responsibilities"),
  requirements: text("requirements"),
  skills: jsonb("skills").$type<string[]>().default(sql`'[]'::jsonb`),
  stipendMin: integer("stipend_min").default(0),
  stipendMax: integer("stipend_max").default(0),
  stipendCurrency: varchar("stipend_currency", { length: 10 }).default("USD"),
  durationMonths: integer("duration_months").default(3),
  applicationDeadline: timestamp("application_deadline", { withTimezone: true }),
  postedAt: timestamp("posted_at", { withTimezone: true }).defaultNow(),
  isActive: boolean("is_active").default(true),
  applicantsCount: integer("applicants_count").default(0),
  tags: jsonb("tags").$type<string[]>().default(sql`'[]'::jsonb`),
  experienceLevel: varchar("experience_level", { length: 50 }).default("entry"),
  perks: text("perks"),
  applicationUrl: varchar("application_url", { length: 512 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const applications = pgTable("applications", {
  id: uuid("id").primaryKey().defaultRandom(),
  internshipId: uuid("internship_id").references(() => internships.id, { onDelete: "cascade" }).notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  university: varchar("university", { length: 255 }),
  graduationYear: integer("graduation_year"),
  resumeUrl: text("resume_url"),
  coverLetter: text("cover_letter"),
  portfolioUrl: varchar("portfolio_url", { length: 512 }),
  linkedinUrl: varchar("linkedin_url", { length: 512 }),
  status: varchar("status", { length: 50 }).default("pending"), // pending | reviewed | shortlisted | rejected | accepted
  appliedAt: timestamp("applied_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export type Internship = typeof internships.$inferSelect;
export type NewInternship = typeof internships.$inferInsert;
export type Application = typeof applications.$inferSelect;
export type NewApplication = typeof applications.$inferInsert;
