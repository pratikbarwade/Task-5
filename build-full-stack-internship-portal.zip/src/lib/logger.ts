type LogLevel = "info" | "warn" | "error" | "debug";

interface LogContext {
  [key: string]: unknown;
}

function formatLog(level: LogLevel, message: string, context?: LogContext) {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    level: level.toUpperCase(),
    message,
    ...context,
    env: process.env.NODE_ENV,
    service: "internship-portal",
  };
  return JSON.stringify(logEntry);
}

export const logger = {
  info: (message: string, context?: LogContext) => {
    console.log(formatLog("info", message, context));
  },
  warn: (message: string, context?: LogContext) => {
    console.warn(formatLog("warn", message, context));
  },
  error: (message: string, context?: LogContext) => {
    console.error(formatLog("error", message, context));
  },
  debug: (message: string, context?: LogContext) => {
    if (process.env.NODE_ENV !== "production") {
      console.debug(formatLog("debug", message, context));
    }
  },
  request: (method: string, path: string, status: number, durationMs: number, extra?: LogContext) => {
    const level: LogLevel = status >= 500 ? "error" : status >= 400 ? "warn" : "info";
    const msg = `${method} ${path} ${status} - ${durationMs}ms`;
    console.log(formatLog(level, msg, { method, path, status, durationMs, ...extra }));
  },
};

export function generateRequestId(): string {
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}
