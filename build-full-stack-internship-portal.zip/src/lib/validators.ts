import { z } from "zod";

export const internshipSchema = z.object({
  title: z.string().min(3).max(255),
  company: z.string().min(2).max(255),
  companyLogo: z.string().url().optional().or(z.literal("")),
  location: z.string().min(2).max(255),
  workType: z.enum(["remote", "hybrid", "onsite"]).default("remote"),
  category: z.string().min(2).max(100),
  employmentType: z.string().min(2).max(50).default("internship"),
  description: z.string().min(20),
  responsibilities: z.string().optional(),
  requirements: z.string().optional(),
  skills: z.array(z.string()).default([]),
  stipendMin: z.number().int().min(0).default(0),
  stipendMax: z.number().int().min(0).default(0),
  stipendCurrency: z.string().default("USD"),
  durationMonths: z.number().int().min(1).max(24).default(3),
  applicationDeadline: z.string().optional().nullable(),
  isActive: z.boolean().default(true),
  tags: z.array(z.string()).default([]),
  experienceLevel: z.enum(["entry", "intermediate", "advanced"]).default("entry"),
  perks: z.string().optional(),
  applicationUrl: z.string().url().optional().or(z.literal("")),
});

export const applicationSchema = z.object({
  internshipId: z.string().uuid(),
  fullName: z.string().min(2).max(255),
  email: z.string().email(),
  phone: z.string().min(5).max(50).optional(),
  university: z.string().min(2).max(255).optional(),
  graduationYear: z.number().int().min(1900).max(2035).optional(),
  resumeUrl: z.string().url().optional().or(z.literal("")),
  coverLetter: z.string().min(20).max(5000),
  portfolioUrl: z.string().url().optional().or(z.literal("")),
  linkedinUrl: z.string().url().optional().or(z.literal("")),
});

export const updateApplicationStatusSchema = z.object({
  status: z.enum(["pending", "reviewed", "shortlisted", "rejected", "accepted"]),
});

export type InternshipInput = z.infer<typeof internshipSchema>;
export type ApplicationInput = z.infer<typeof applicationSchema>;
