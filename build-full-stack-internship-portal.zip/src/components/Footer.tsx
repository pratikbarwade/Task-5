import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white" role="contentinfo">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white font-bold">I</div>
              <span className="text-xl font-bold">InternBoard</span>
            </div>
            <p className="mt-4 max-w-md text-sm leading-6 text-slate-600">
              Production-ready internship portal built for students and recruiters. Discover remote, hybrid, and onsite internships from leading companies. Fictional data for demo purposes.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <span className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                <span className="mr-1.5 h-2 w-2 rounded-full bg-emerald-500 animate-pulse" aria-hidden="true"></span>
                All systems operational
              </span>
              <span className="text-xs text-slate-500">v1.0.0 • Production Ready</span>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900">Platform</h3>
            <ul className="mt-4 space-y-3">
              <li><Link href="/internships" className="text-sm text-slate-600 hover:text-slate-900">Browse Internships</Link></li>
              <li><Link href="/dashboard" className="text-sm text-slate-600 hover:text-slate-900">My Applications</Link></li>
              <li><Link href="/post" className="text-sm text-slate-600 hover:text-slate-900">Post Internship</Link></li>
              <li><Link href="/api/health" className="text-sm text-slate-600 hover:text-slate-900">System Health</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-slate-900">Resources</h3>
            <ul className="mt-4 space-y-3">
              <li><a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-sm text-slate-600 hover:text-slate-900">GitHub Repository</a></li>
              <li><Link href="/#how-it-works" className="text-sm text-slate-600 hover:text-slate-900">How it Works</Link></li>
              <li><span className="text-sm text-slate-500">Fictional Data Only</span></li>
              <li><span className="text-sm text-slate-500">Beginner Friendly</span></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-200 pt-8">
          <p className="text-xs text-slate-500">© {new Date().getFullYear()} InternBoard. Built as production-ready capstone. No real jobs — fictional data for demonstration.</p>
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span>Accessibility: WCAG AA</span>
            <span>•</span>
            <span>Performance: Optimized</span>
            <span>•</span>
            <span>Security: Hardened</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
