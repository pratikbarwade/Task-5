"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { CATEGORIES } from "@/lib/utils";

export default function Filters() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const updateParam = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (!value || value === "all") {
      params.delete(key);
    } else {
      params.set(key, value);
    }
    params.set("page", "1");
    router.push(`/internships?${params.toString()}`);
  };

  const clearAll = () => {
    router.push("/internships");
  };

  const currentWorkType = searchParams.get("workType") || "all";
  const currentCategory = searchParams.get("category") || "all";
  const currentExperience = searchParams.get("experience") || "all";
  const currentSort = searchParams.get("sort") || "newest";

  const hasFilters = currentWorkType !== "all" || currentCategory !== "all" || currentExperience !== "all";

  return (
    <div className="space-y-6 rounded-2xl border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-900">Filters</h2>
        {hasFilters && (
          <button onClick={clearAll} className="text-xs font-medium text-indigo-600 hover:text-indigo-700">Clear all</button>
        )}
      </div>

      <div>
        <label htmlFor="worktype-select" className="block text-xs font-medium text-slate-700 mb-2">Work Type</label>
        <select
          id="worktype-select"
          value={currentWorkType}
          onChange={(e) => updateParam("workType", e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All types</option>
          <option value="remote">Remote</option>
          <option value="hybrid">Hybrid</option>
          <option value="onsite">Onsite</option>
        </select>
      </div>

      <div>
        <label htmlFor="category-select" className="block text-xs font-medium text-slate-700 mb-2">Category</label>
        <select
          id="category-select"
          value={currentCategory}
          onChange={(e) => updateParam("category", e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All categories</option>
          {CATEGORIES.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="exp-select" className="block text-xs font-medium text-slate-700 mb-2">Experience</label>
        <select
          id="exp-select"
          value={currentExperience}
          onChange={(e) => updateParam("experience", e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
        >
          <option value="all">All levels</option>
          <option value="entry">Entry Level</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>
      </div>

      <div>
        <label htmlFor="sort-select" className="block text-xs font-medium text-slate-700 mb-2">Sort by</label>
        <select
          id="sort-select"
          value={currentSort}
          onChange={(e) => updateParam("sort", e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
        >
          <option value="newest">Newest first</option>
          <option value="stipend_high">Highest stipend</option>
          <option value="stipend_low">Lowest stipend</option>
          <option value="deadline">Deadline soon</option>
        </select>
      </div>

      <div className="pt-4 border-t border-slate-100">
        <h3 className="text-xs font-medium text-slate-700 mb-2">Quick Tips</h3>
        <ul className="space-y-1 text-xs text-slate-500 list-disc list-inside">
          <li>Use search for skills like React, Python</li>
          <li>Remote roles are 40% of listings</li>
          <li>Apply early - deadlines matter</li>
        </ul>
      </div>
    </div>
  );
}
