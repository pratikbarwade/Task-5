"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

interface Props {
  internshipId: string;
  internshipTitle: string;
}

export default function ApplicationForm({ internshipId, internshipTitle }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    university: "",
    graduationYear: "",
    resumeUrl: "",
    coverLetter: "",
    portfolioUrl: "",
    linkedinUrl: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (!form.fullName || !form.email || !form.coverLetter) {
      setError("Please fill in all required fields.");
      setLoading(false);
      return;
    }

    if (form.coverLetter.length < 20) {
      setError("Cover letter must be at least 20 characters.");
      setLoading(false);
      return;
    }

    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          internshipId,
          fullName: form.fullName,
          email: form.email,
          phone: form.phone || undefined,
          university: form.university || undefined,
          graduationYear: form.graduationYear ? parseInt(form.graduationYear, 10) : undefined,
          resumeUrl: form.resumeUrl || undefined,
          coverLetter: form.coverLetter,
          portfolioUrl: form.portfolioUrl || undefined,
          linkedinUrl: form.linkedinUrl || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to submit application");
      }

      setSuccess(true);
      // Store email for dashboard convenience
      localStorage.setItem("lastApplicantEmail", form.email);
      setTimeout(() => {
        router.push(`/dashboard?email=${encodeURIComponent(form.email)}`);
      }, 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-8 text-center animate-fadeIn" role="status" aria-live="polite">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100">
          <svg className="h-6 w-6 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
        </div>
        <h3 className="mt-4 text-lg font-semibold text-emerald-900">Application Submitted!</h3>
        <p className="mt-2 text-sm text-emerald-700">Your application for <strong>{internshipTitle}</strong> has been received. Redirecting to dashboard...</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8" aria-labelledby="apply-heading">
      <div>
        <h2 id="apply-heading" className="text-xl font-bold text-slate-900">Apply for {internshipTitle}</h2>
        <p className="mt-1 text-sm text-slate-600">Fictional application — no real data will be shared. Use dummy info for demo.</p>
      </div>

      {error && (
        <div className="rounded-xl bg-red-50 border border-red-200 p-4 text-sm text-red-700" role="alert">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-slate-700">Full Name <span className="text-red-500">*</span></label>
          <input id="fullName" name="fullName" required value={form.fullName} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="Alex Johnson" />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-slate-700">Email <span className="text-red-500">*</span></label>
          <input id="email" name="email" type="email" required value={form.email} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="alex@university.edu" />
        </div>
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-slate-700">Phone</label>
          <input id="phone" name="phone" value={form.phone} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="+1 555 0100" />
        </div>
        <div>
          <label htmlFor="university" className="block text-sm font-medium text-slate-700">University</label>
          <input id="university" name="university" value={form.university} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="Stanford University" />
        </div>
        <div>
          <label htmlFor="graduationYear" className="block text-sm font-medium text-slate-700">Graduation Year</label>
          <input id="graduationYear" name="graduationYear" type="number" min={2020} max={2035} value={form.graduationYear} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="2026" />
        </div>
        <div>
          <label htmlFor="resumeUrl" className="block text-sm font-medium text-slate-700">Resume URL</label>
          <input id="resumeUrl" name="resumeUrl" type="url" value={form.resumeUrl} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="https://drive.google.com/..." />
        </div>
        <div>
          <label htmlFor="portfolioUrl" className="block text-sm font-medium text-slate-700">Portfolio URL</label>
          <input id="portfolioUrl" name="portfolioUrl" type="url" value={form.portfolioUrl} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="https://yourportfolio.com" />
        </div>
        <div>
          <label htmlFor="linkedinUrl" className="block text-sm font-medium text-slate-700">LinkedIn URL</label>
          <input id="linkedinUrl" name="linkedinUrl" type="url" value={form.linkedinUrl} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="https://linkedin.com/in/..." />
        </div>
      </div>

      <div>
        <label htmlFor="coverLetter" className="block text-sm font-medium text-slate-700">Cover Letter <span className="text-red-500">*</span></label>
        <textarea id="coverLetter" name="coverLetter" required rows={5} value={form.coverLetter} onChange={handleChange} className="mt-1 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500" placeholder="Tell us why you're a great fit for this internship... (min 20 chars)"></textarea>
        <p className="mt-1 text-xs text-slate-500">{form.coverLetter.length}/5000 characters</p>
      </div>

      <div className="flex items-center gap-3 pt-2">
        <button type="submit" disabled={loading} className="inline-flex flex-1 sm:flex-none items-center justify-center rounded-xl bg-indigo-600 px-8 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
          {loading ? "Submitting..." : "Submit Application"}
        </button>
        <button type="button" onClick={() => router.back()} className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50">Cancel</button>
      </div>

      <p className="text-xs text-slate-500">By applying, you agree that this is fictional data for demonstration. No real personal data is processed beyond this demo.</p>
    </form>
  );
}
