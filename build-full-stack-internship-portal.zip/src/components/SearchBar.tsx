"use client";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

interface Props {
  initialSearch?: string;
  initialLocation?: string;
}

export default function SearchBar({ initialSearch = "", initialLocation = "" }: Props) {
  const [search, setSearch] = useState(initialSearch);
  const [location, setLocation] = useState(initialLocation);
  const router = useRouter();
  const params = useSearchParams();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newParams = new URLSearchParams(params.toString());
    if (search) newParams.set("search", search);
    else newParams.delete("search");
    if (location) newParams.set("location", location);
    else newParams.delete("location");
    newParams.set("page", "1");
    router.push(`/internships?${newParams.toString()}`);
  };

  return (
    <form onSubmit={handleSubmit} role="search" aria-label="Search internships" className="w-full">
      <div className="flex flex-col sm:flex-row gap-3 rounded-2xl bg-white p-2 shadow-lg ring-1 ring-slate-200">
        <div className="relative flex-1">
          <label htmlFor="search-input" className="sr-only">Search internships</label>
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
            <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
          <input
            id="search-input"
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Job title, company, or keywords"
            className="w-full rounded-xl border-0 bg-slate-50 py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-500 focus:bg-white focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div className="relative sm:w-64">
          <label htmlFor="location-input" className="sr-only">Location</label>
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
            <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          </div>
          <input
            id="location-input"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Location or Remote"
            className="w-full rounded-xl border-0 bg-slate-50 py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-500 focus:bg-white focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button
          type="submit"
          className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-6 py-3 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 transition-colors"
        >
          Search
        </button>
      </div>
    </form>
  );
}
