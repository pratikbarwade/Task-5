import Link from "next/link";
import { formatCurrency, timeAgo } from "@/lib/utils";
import type { Internship } from "@/db/schema";

interface Props {
  internship: Internship;
}

export default function InternshipCard({ internship }: Props) {
  const skills = (internship.skills as string[]) || [];
  const tags = (internship.tags as string[]) || [];

  return (
    <article className="group relative flex flex-col rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm transition-all hover:shadow-lg hover:border-slate-300 hover:-translate-y-0.5 focus-within:ring-2 focus-within:ring-indigo-500">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 overflow-hidden rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center">
            {internship.companyLogo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={internship.companyLogo} alt={`${internship.company} logo`} className="h-full w-full object-cover" loading="lazy" />
            ) : (
              <span className="text-sm font-bold text-slate-600">{internship.company.charAt(0)}</span>
            )}
          </div>
          <div>
            <h3 className="text-[15px] font-semibold text-slate-900 line-clamp-1">
              <Link href={`/internships/${internship.id}`} className="hover:text-indigo-600 focus:outline-none">
                <span className="absolute inset-0" aria-hidden="true" />
                {internship.title}
              </Link>
            </h3>
            <p className="text-sm text-slate-600">{internship.company} • {internship.location}</p>
          </div>
        </div>
        <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${
          internship.workType === "remote" ? "bg-emerald-50 text-emerald-700 ring-emerald-600/20" :
          internship.workType === "hybrid" ? "bg-amber-50 text-amber-700 ring-amber-600/20" :
          "bg-blue-50 text-blue-700 ring-blue-600/20"
        }`}>
          {internship.workType}
        </span>
      </div>

      <p className="mt-4 line-clamp-2 text-sm leading-6 text-slate-600">{internship.description}</p>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {skills.slice(0, 3).map((skill) => (
          <span key={skill} className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700">
            {skill}
          </span>
        ))}
        {skills.length > 3 && (
          <span className="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-1 text-xs text-slate-500">+{skills.length - 3}</span>
        )}
      </div>

      <div className="mt-5 flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-xs text-slate-500">Stipend</span>
          <span className="text-sm font-semibold text-slate-900">
            {formatCurrency(internship.stipendMin || 0)} - {formatCurrency(internship.stipendMax || 0)}
          </span>
        </div>
        <div className="text-right">
          <span className="text-xs text-slate-500">{internship.category}</span>
          <div className="flex items-center gap-1 text-xs text-slate-500">
            <span aria-hidden="true">•</span>
            <time dateTime={internship.postedAt ? new Date(internship.postedAt).toISOString() : undefined}>{internship.postedAt ? timeAgo(internship.postedAt) : "New"}</time>
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
        <span className="text-xs text-slate-500">{internship.applicantsCount || 0} applicants • {internship.durationMonths} months</span>
        <span className="inline-flex items-center text-sm font-medium text-indigo-600 group-hover:text-indigo-700">
          View details
          <svg className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
        </span>
      </div>
    </article>
  );
}
