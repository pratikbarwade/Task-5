# InternBoard — Production-Ready Internship Portal

> **Capstone 05: Production-Ready Capstone**  
> Turn previous milestones into a polished full-stack internship portal and present engineering decisions.

A beginner-friendly, mobile-responsive, production-ready internship board built with Next.js 15, PostgreSQL, Drizzle ORM, and Tailwind CSS. All data is fictional for demo purposes.

**Live Demo:** Deploy to Vercel / Railway / Render — see `docs/DEPLOYMENT.md`  
**One Proof Link:** This repository contains everything — app, docs, test evidence, video plan.

---

## 🎯 Objective

Demonstrate deployment, documentation, quality assurance, performance, and product thinking by polishing the complete user journey from Task 3 (backend API) and Task 4 (frontend integration).

### Deliverable
- Live application
- GitHub repository (this repo)
- Test evidence (`docs/TEST_EVIDENCE.md`)
- Walkthrough video link (`docs/WALKTHROUGH_VIDEO_PLAN.md`)

---

## ✨ Features

### For Students
- 🔍 **Search & Filter** — Title, company, skills, location, work type (remote/hybrid/onsite), category, experience level, stipend, sorting (newest, stipend, deadline)
- 📄 **Internship Detail** — Full description, responsibilities, requirements, skills, perks, applicant count, deadline
- ⚡ **60-Second Apply** — No account needed, email-based tracking, validation, duplicate prevention, rate limiting
- 📊 **Dashboard** — View applications by email, status tracking (pending, reviewed, shortlisted, accepted, rejected)

### For Recruiters / Admin
- ➕ **Post Internship** — Production validation with Zod, structured logging
- 🛠 **Manage** — List, delete internships, view applicant counts
- 📈 **Stats API** — Total internships, remote count, applications by status, categories

### Platform Engineering
- 🏥 **Health Check** — `/api/health` returns DB status, memory, uptime, latency, version
- 📝 **Meaningful Logging** — JSON structured logs with requestId, method, path, status, duration, context
- 🔒 **Security** — Zod validation, Drizzle parameterized queries (SQL injection safe), rate limiting, XSS prevention, no secrets in client
- ♿ **Accessibility** — Semantic HTML, ARIA labels, skip link, focus-visible, keyboard navigation, WCAG AA contrast, alt text
- ⚡ **Performance** — Pagination, caching headers, lazy images, responsive images, minimal JS, Tailwind
- 📱 **Mobile-Friendly** — Hamburger menu, responsive grid, touch targets 44px+, fluid typography

---

## 🏗 Tech Stack

- **Frontend:** Next.js 16 (App Router), React 19, Tailwind CSS 4, TypeScript
- **Backend:** Next.js API Routes, Drizzle ORM 0.45, PostgreSQL (pg driver)
- **Validation:** Zod
- **Logging:** Custom structured JSON logger
- **Deployment:** Vercel-ready, Dockerfile-friendly

---

## 📁 Project Structure

```
src/
  app/
    api/
      health/         # Enhanced health check
      internships/    # CRUD + filtering
      applications/   # Apply + status update
      stats/          # Aggregated metrics
      seed/           # Seed fictional data
    internships/      # Listing + [id] detail
    dashboard/        # My applications + manage
    post/             # Post internship form
    page.tsx          # Homepage with hero, featured, how-it-works
    layout.tsx        # Header, Footer, skip link, metadata
  components/
    Header.tsx        # Responsive nav, mobile menu
    Footer.tsx        # System status, links
    InternshipCard.tsx
    SearchBar.tsx
    Filters.tsx
    ApplicationForm.tsx
  lib/
    logger.ts         # Structured logging
    validators.ts     # Zod schemas
    rateLimit.ts      # In-memory rate limiter
    utils.ts          # Helpers, constants
  db/
    schema.ts         # internships, applications tables
    index.ts          # Drizzle pool
docs/
  ARCHITECTURE.md
  API_CONTRACT.md
  TEST_EVIDENCE.md
  DEPLOYMENT.md
  ACCESSIBILITY_AUDIT.md
  PERFORMANCE_REPORT.md
  SECURITY_CHECKLIST.md
  WALKTHROUGH_VIDEO_PLAN.md
  QA_CHECKLIST.md
```

---

## 🚀 Quick Start (Beginner-Friendly)

### Prerequisites
- Node.js 18+
- PostgreSQL running locally or remote URL

### 1. Clone & Install
```bash
git clone <your-repo>
cd internship-portal
npm install
```

### 2. Env Setup
Create `.env`:
```
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
```
Copy `.env.example` if present.

### 3. DB Setup
```bash
npx drizzle-kit push
# or via npm script if configured
```

### 4. Seed Fictional Data
```bash
curl -X POST http://localhost:3000/api/seed
# Or visit /api/seed and POST via UI
```
Alternatively, use the app: homepage will show seed prompt if empty.

### 5. Run Dev
```bash
npm run dev
# http://localhost:3000
```

### 6. Build & Start (Production)
```bash
npm run build
npm start
```

---

## 🔌 API Contract

See `docs/API_CONTRACT.md` for full spec.

**Base:** `/api`

- `GET /health` — System health
- `GET /internships?search=&location=&workType=&category=&experience=&page=&limit=&sort=` — List with filters
- `GET /internships/:id` — Detail
- `POST /internships` — Create (validated)
- `PUT /internships/:id` — Update
- `DELETE /internships/:id` — Delete
- `GET /applications?email=&internshipId=&status=` — List
- `POST /applications` — Apply (duplicate check, rate limited)
- `PATCH /applications/:id` — Update status
- `GET /stats` — Aggregated counts
- `POST /seed` — Seed fictional data

All responses include `X-Request-Id` header, structured logs.

---

## 🧪 Quality Assurance

We ran 4 checks + regression:

1. **Accessibility** — Keyboard nav, screen reader labels, color contrast 4.5:1, skip link, focus-visible. Report: `docs/ACCESSIBILITY_AUDIT.md`
2. **Performance** — Pagination (12 per page), caching headers (`s-maxage=30`), lazy images, no large bundles. Report: `docs/PERFORMANCE_REPORT.md`
3. **Security** — Zod validation, Drizzle param queries, rate limiting (60 req/min), no XSS, env secrets server-only. Checklist: `docs/SECURITY_CHECKLIST.md`
4. **Regression** — Critical flows tested: search → filter → view → apply → dashboard → post → delete. Evidence: `docs/TEST_EVIDENCE.md`

---

## 📱 Mobile Experience Polish

- Hamburger menu with `aria-expanded`, focus trap via auto-close on navigation
- Search bar stacks vertically on <640px, rounded-2xl touch targets
- Cards: single column on mobile, 2 on tablet, 3 on desktop
- Forms: 44px min height, labels always visible, error announcements via `role="alert"`
- Tables: horizontal scroll with `overflow-x-auto`, not breaking layout
- Hero: fluid typography `clamp()`, grid stats responsive

---

## 📝 Logging Example

```json
{"timestamp":"2026-05-11T...","level":"INFO","message":"GET /api/internships 200 - 42ms","method":"GET","path":"/api/internships","status":200,"durationMs":42,"requestId":"abc123","service":"internship-portal"}
{"timestamp":"...","level":"WARN","message":"Rate limit exceeded","requestId":"...","path":"/api/applications","ip":"..."}
```

Logs appear in server console, searchable in production log aggregator.

---

## 🚢 Deployment

See `docs/DEPLOYMENT.md`. Summary:

- **Vercel:** Connect GitHub, set `DATABASE_URL`, deploy. Add `vercel.json` caching.
- **Docker:** Use Node 20 Alpine, `npm run build`, `npm start`, healthcheck `GET /api/health`.
- **Env:** Only `DATABASE_URL` required. No client secrets.
- **Migrations:** `npx drizzle-kit push` on deploy, or run seed endpoint once.

---

## 🎥 Walkthrough Video Plan

See `docs/WALKTHROUGH_VIDEO_PLAN.md` — 5-minute script covering user journey, architecture, QA, and engineering decisions.

---

## 👩‍💻 Beginner Friendly Notes

- No auth complexity — email-based to focus on core flow
- Comments in code explain why, not just what
- Fictional data only — safe to demo, no real PII
- All docs in `docs/` folder, one proof link satisfies submission
- `npm run build` must pass — we fixed all type errors

---

## 📄 License

MIT — Fictional data, educational purpose.

---

## ✅ Submission Checklist (from Task Guide)

- [x] Polished user journey + mobile experience
- [x] Logging, health checks, useful README
- [x] Accessibility, performance, security, regression checks + fixes
- [x] One public link with all supporting files in same repo
- [x] Fictional data only
- [x] Beginner-friendly, production-ready, GitHub-ready
- [x] Docs, test evidence, video plan included

**One Proof Link:** Provide this GitHub repo URL or deployed URL that links to repo.

