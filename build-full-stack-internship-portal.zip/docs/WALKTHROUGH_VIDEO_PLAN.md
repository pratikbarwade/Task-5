# Walkthrough / Demo Video Plan — InternBoard

**Duration:** 5-7 minutes (target 5 min)
**Tool:** Loom, OBS, or phone screen record + voiceover
**Audience:** Reviewer, hiring manager, portfolio viewer
**Goal:** Show complete user journey, engineering decisions, QA, production readiness

## Video Structure

### 0:00-0:30 — Intro & Objective
- Show self, say: "Hi, I'm [Your Name], this is InternBoard — production-ready internship portal built as Capstone 05."
- Objective: Demonstrate deployment, documentation, QA, performance, product thinking
- Tech stack slide or README: Next.js, Postgres, Drizzle, Tailwind, Zod
- Mention: Fictional data only, beginner-friendly, GitHub-ready

### 0:30-1:30 — User Journey: Student
- **Homepage**: Show hero, stats, search bar, featured internships (mobile responsive — resize browser to phone width, show hamburger)
- **Search**: Type "React" -> shows filtered, URL updates ?search=React — shareable URL
- **Filters**: Show workType remote, category Software Engineering, sort stipend high — demonstrate mobile sidebar
- **Detail**: Click card -> detail page, show breadcrumb, company logo, stipend, skills, responsibilities, applicant count
- **Apply**: Scroll to apply form, fill with fictional data (Alex Johnson, alex@demo.com, cover letter 50 chars), submit -> success green state, redirect to dashboard
- **Dashboard**: Show email pre-filled, application appears with pending status, table responsive

### 1:30-2:15 — User Journey: Recruiter
- **Post**: Go to /post, show validation (try empty submit -> error), then fill valid internship (title, company, location, description), submit -> 201, redirect to new detail
- **Manage**: Dashboard -> Manage tab, show new internship, applicant count, delete flow with confirm
- **Stats**: Show /api/stats JSON, explain metrics

### 2:15-3:00 — Engineering Decisions & Architecture
- Show `docs/ARCHITECTURE.md` — diagram, data model, why monolith (beginner-friendly, single deploy)
- Show `src/db/schema.ts` — two tables, jsonb for skills/tags
- Show `src/lib/logger.ts` — structured JSON logging, requestId
- Show `src/lib/validators.ts` — Zod schemas, validation
- Show `src/lib/rateLimit.ts` — in-memory rate limiter, cleanup, future Redis
- Explain: RSC for performance, client components for interactivity, pagination, caching headers

### 3:00-4:00 — Quality Assurance (QA Checks)
- **Accessibility**: Show skip link (Tab), keyboard nav through header, focus-visible ring, labels, alt text, contrast. Show `docs/ACCESSIBILITY_AUDIT.md`
- **Performance**: Show `npm run build` output ~90kB JS, show /api/health latency 8ms, show caching headers in DevTools Network, lazy images. Show `docs/PERFORMANCE_REPORT.md`
- **Security**: Show Zod validation blocking short title, SQL injection test `' OR 1=1` safe, XSS `<script>` rendered as text, rate limiting 429. Show `docs/SECURITY_CHECKLIST.md`
- **Regression**: Show `docs/TEST_EVIDENCE.md` — 39 checks all PASS, critical flows

### 4:00-4:45 — Production Readiness
- **Health**: Visit /api/health -> show healthy, DB ok, memory, uptime, version
- **Logging**: Show terminal logs JSON structured, request logs with duration
- **Mobile**: Resize to 375px iPhone SE, show hamburger, search stacks, cards 1 col, form touch targets, no horizontal scroll
- **Deployment**: Show Vercel dashboard or README deployment steps, env vars, seed endpoint
- **README**: Scroll through README — quick start, API contract, features, checklist

### 4:45-5:15 — Documentation & Submission
- Show GitHub repo: one proof link contains everything — app, docs/, README, test evidence
- Show docs folder: 8 docs, all in same repo
- Show how to run: `npm install`, `npx drizzle-kit push`, `curl -X POST /api/seed`, `npm run dev`
- Mention: Fictional data only, beginner-friendly, production-ready, GitHub-ready

### 5:15-5:30 — Outro & Next Steps
- Recap: Polished user journey, mobile, logging, health, QA checks fixed, deployment ready
- Future improvements: Auth, S3 upload, Redis rate limit, full-text search, tests
- Thank you, provide GitHub link and live link in description

## Script Tips

- Speak slowly, explain why not just what
- Show code briefly, not too long
- Always show mobile responsiveness by resizing
- Show real interactions, not just slides
- Mention "fictional data only" multiple times
- Show logs, health, error states

## Recording Checklist

- [ ] Clean browser, no personal bookmarks
- [ ] Use incognito to avoid extensions
- [ ] Prepare fictional data in clipboard (Alex Johnson, etc.)
- [ ] Seed DB beforehand so featured shows
- [ ] Have terminal ready for build logs
- [ ] Have docs open in tabs
- [ ] Test audio, screen capture
- [ ] 1080p, 30fps, show entire screen

## Loom / Video Settings

- Title: "InternBoard — Production-Ready Capstone Walkthrough (5 min)"
- Description: Include GitHub repo link, live deployed link, README link, timestamp chapters
- Chapters:
  - 0:00 Intro
  - 0:30 Student Journey
  - 1:30 Recruiter Journey
  - 2:15 Architecture
  - 3:00 QA Checks
  - 4:00 Production Readiness
  - 4:45 Docs & Submission

## Submission Link

Upload video to Loom (public) or YouTube (unlisted), add link to README and provide as proof link alongside GitHub repo. Task says "Submit one public or view-only link. Put supporting files in same repository/folder" — so best is GitHub repo URL that contains video link in README.

Example README addition:
```
## Demo Video
Loom: https://www.loom.com/share/...
```

## Optional Portfolio Upgrade (from screenshot)

- Add personal branding to footer
- Add case study blog post
- Add LinkedIn post about engineering decisions

## Done Criteria

- Video <10 min, ideally 5-7
- Shows mobile responsiveness
- Shows complete user journey
- Explains engineering decisions
- Shows QA evidence
- One link submission with all files
