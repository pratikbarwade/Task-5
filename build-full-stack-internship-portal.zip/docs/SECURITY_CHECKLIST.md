# Security Checklist — InternBoard

Date: 2026-05-11
Standard: OWASP Top 10, basic production hardening

## 1. Injection

### SQL Injection
- [x] **Mitigated**: Using Drizzle ORM with parameterized queries, no string concatenation. All queries use `eq()`, `ilike()`, etc., which parameterize.
- Test: Input `' OR 1=1 --` in search -> returns 0 results, no error, no dump — PASS

### XSS
- [x] **Mitigated**: No `dangerouslySetInnerHTML`. All user content rendered as text. React escapes by default.
- Test: Submit `<script>alert(1)</script>` in cover letter -> stored as text, rendered as text, not executed — PASS
- [x] No inline event handlers from user data

### NoSQL, etc.
- [x] Not using NoSQL, but JSONB fields validated via Zod array of strings, not raw.

## 2. Broken Authentication

- [x] **N/A for demo**: No auth, email-based. For production, would need NextAuth, password hashing, session.
- [x] No sensitive data exposed: applications require email query, but no auth — acceptable for demo, flagged as fictional. For real, add auth.
- [x] No JWT, no session fixation.

## 3. Sensitive Data Exposure

- [x] `DATABASE_URL` server-only, not prefixed NEXT_PUBLIC, never sent to client. Verified via grep.
- [x] No API keys in repo, .env not committed (gitignore).
- [x] Error messages generic: 500 returns "Internal server error", not stack trace. Logs contain details server-side only.
- [x] No PII in logs: email logged only on creation, not full cover letter.

## 4. XML External Entities
- [x] N/A — JSON only, no XML parsing.

## 5. Broken Access Control

- [x] **IDOR**: Applications list filtered by email query, but anyone knowing email can see. For demo okay, but note: production needs auth.
- [x] No admin endpoints without protection? Post/delete internships open — for demo okay, but production would require role check.
- [x] Mitigation: Rate limiting prevents brute force enumeration.
- Future: Add API key or session for write operations.

## 6. Security Misconfiguration

- [x] No directory listing, Next.js handles.
- [x] No verbose error: 500 generic.
- [x] Headers: X-Request-Id for tracing, Cache-Control for sensitive? Applications no-cache? Currently no cache header for applications (good). List has cache but public data.
- [x] No default credentials: DB URL required, fails fast if missing.
- [x] Dependencies: npm audit — 11 vulnerabilities (1 low, 4 moderate, 6 high) from Next.js peer? Need `npm audit fix` but kept for demo. Recommendation: run audit fix.

## 7. Cross-Site Scripting (XSS) — Covered in Injection

## 8. Insecure Deserialization
- [x] N/A — JSON only, Zod validates shape.

## 9. Using Components with Known Vulnerabilities

- [x] Dependencies: Next 16.2.6, React 19.2.6, Drizzle 0.45.2, pg 8.20.0 — recent versions.
- [x] `npm audit` shows 11 vulns, mostly from Next.js dev? Should run `npm audit fix` — but not breaking for demo.
- Future: Enable Dependabot, `npm audit` in CI.

## 10. Insufficient Logging & Monitoring

- [x] **Fixed**: Added structured JSON logger with timestamp, level, requestId, method, path, status, duration.
- [x] Logs: info for normal, warn for rate limit/validation, error for DB failures.
- [x] Health check: /api/health for monitoring.
- [x] Request logging: every API logs request with duration.

## Additional Hardening

### Validation
- [x] Zod schemas for all POST/PUT/PATCH: length limits, email format, URL format, enum checks, int ranges.
- [x] Unknown fields stripped (Zod default).
- [x] Example: title min 3 max 255 prevents huge payload.

### Rate Limiting
- [x] In-memory rate limiter: 60 req/min per IP per route. Prevents brute force, spam.
- [x] Returns 429 with Retry-After.
- [x] Cleanup interval prevents memory leak.

### CORS
- [x] Same-origin by default (Next.js API). No CORS headers wildcard.
- [x] No need for CORS as frontend same domain.

### CSRF
- [x] N/A for JSON API, no cookies. If adding auth with cookies, need CSRF token.

### Security Headers (Future)
- [ ] Could add: `Content-Security-Policy`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`
- Next.js `next.config.ts` can add headers — recommend adding for production.

### File Upload
- [x] No file upload, only URL fields — prevents malicious file upload. If adding resume upload, need virus scan, S3, type check.

### Environment
- [x] `.env` not committed, `.env.example` provided.
- [x] `NODE_ENV` checks for debug logs.

## Test Evidence

- SQL injection test: search `' OR 1=1 --` -> safe — PASS
- XSS test: `<script>` stored as text — PASS
- Rate limit test: 61 rapid requests -> 429 — PASS
- Validation test: title "ab" -> 400 — PASS
- Secrets test: grep client bundle for DATABASE_URL -> not found — PASS

## Risk Assessment

- **Low Risk**: SQLi, XSS, secret exposure — mitigated.
- **Medium Risk**: No auth for write operations — acceptable for demo fictional data, but document as limitation. For real production, add auth.
- **Low Risk**: Dependencies vulns — run audit fix before deploy.

## Recommendations for Production

1. Add NextAuth with email magic link for students, role-based for recruiters
2. Add security headers in next.config.ts
3. Run `npm audit fix` and enable Dependabot
4. Use Redis for rate limiting in multi-instance
5. Add CAPTCHA for application form to prevent spam
6. Add file upload to S3 with presigned URLs, not direct URL input
7. Enable Vercel WAF or Cloudflare

Overall: PASS basic security checklist for demo, with documented limitations.
