# Deployment Guide — InternBoard

## Overview
Production-ready deployment for Vercel (recommended), or any Node platform (Railway, Render, Fly, Docker).

## Prerequisites
- PostgreSQL database (Neon, Supabase, Vercel Postgres, Railway Postgres, or self-hosted)
- Node.js 18+
- DATABASE_URL

## Option 1: Vercel (Easiest, Beginner-Friendly)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Production-ready internship portal"
   git branch -M main
   git remote add origin https://github.com/yourname/internboard.git
   git push -u origin main
   ```

2. **Import to Vercel**
   - Go to vercel.com, Import Git Repository
   - Select internboard
   - Framework Preset: Next.js
   - Build Command: `npm run build` (default)
   - Output Directory: default

3. **Environment Variables**
   - In Vercel dashboard -> Settings -> Environment Variables
   - Add `DATABASE_URL` = your Postgres URL (e.g., from Neon: `postgresql://user:pass@ep-...neon.tech/db?sslmode=require`)

4. **Deploy**
   - Click Deploy
   - Wait for build logs: should show 5 routes, no type errors
   - Visit deployed URL

5. **Seed Database**
   - Once live, POST to seed:
   ```bash
   curl -X POST https://your-app.vercel.app/api/seed
   ```
   - Or visit `/api/seed` in browser and use DevTools to POST, or add temporary button.

6. **Verify Health**
   - Visit `/api/health` -> should be `{"status":"healthy",...}`

## Option 2: Railway / Render

### Railway
1. Create new project -> Deploy from GitHub
2. Add PostgreSQL plugin -> copy DATABASE_URL
3. Set variable DATABASE_URL in service
4. Deploy, same seed step

### Render
1. New Web Service -> Connect GitHub
2. Build Command: `npm install && npm run build`
3. Start Command: `npm start`
4. Add Environment: DATABASE_URL, NODE_ENV=production
5. Create PostgreSQL in Render, link
6. Deploy

## Option 3: Docker

**Dockerfile** (create if needed):
```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/package*.json ./
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/node_modules ./node_modules
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://localhost:3000/api/health | grep healthy || exit 1
CMD ["npm","start"]
```

Build & run:
```bash
docker build -t internboard .
docker run -p 3000:3000 -e DATABASE_URL=postgresql://... internboard
```

## Database Migrations

This project uses `drizzle-kit push` (no migration files for simplicity).

**Local:**
```bash
npx drizzle-kit push
```

**Production:**
- Vercel: Add build command `npx drizzle-kit push && npm run build` OR run manually via `psql`
- Or use Drizzle migrations: `npx drizzle-kit generate` then `npx drizzle-kit migrate`

**Schema:** Defined in `src/db/schema.ts` — two tables: internships, applications.

## Environment Variables

| Var | Required | Example | Notes |
|-----|----------|---------|-------|
| DATABASE_URL | Yes | postgresql://... | Server-only, never client |
| NODE_ENV | No | production | Set by platform |

No NEXT_PUBLIC vars needed.

## Post-Deploy Checklist

- [ ] Visit `/` — hero loads, featured internships
- [ ] Visit `/api/health` — healthy
- [ ] POST `/api/seed` if empty
- [ ] Test search, filter, apply, dashboard
- [ ] Check logs: structured JSON logs in platform logs
- [ ] Set custom domain (optional)
- [ ] Enable analytics (Vercel Analytics)

## Monitoring

- Health endpoint: `/api/health` — use UptimeRobot, BetterStack to ping every 5min, alert if 503
- Logs: Vercel -> Logs tab shows JSON logs, filter by level
- Metrics: `/api/stats` for business metrics

## Rollback

- Vercel: Deployments tab -> Redeploy previous
- DB: No destructive migrations, safe to rollback code

## Cost

- Vercel Hobby: Free, includes Postgres free tier (Neon free 3GB)
- Railway: $5/mo starter
- Render: Free tier sleeps, good for demo

## One Proof Link Submission

For task submission, provide **one link** that contains everything:

- **Option A (Recommended):** GitHub repo URL — contains app + docs/ folder + README + video plan. Live URL in README.
- **Option B:** Deployed Vercel URL — ensure repo link in footer, docs accessible via /docs? Actually docs in repo, so provide GitHub link in footer and README.
- **Option C:** Notion / Google Drive folder containing GitHub link + deployed link + video link — but task says put supporting files in same repository/folder, so GitHub repo is simplest.

**Example Submission Link:** `https://github.com/yourname/internboard` with README containing live URL and Loom video link.

## Troubleshooting

- **Build fails typegen**: Run `npx next typegen`, fix TS errors
- **DB connection fails**: Check DATABASE_URL, sslmode=require for Neon
- **Seed fails**: Ensure DB empty or count <=5, else returns already seeded
- **429 Too Many Requests**: Wait 60s, rate limiter
- **500 Internal**: Check logs for DB error, ensure `drizzle-kit push` ran

## Production Readiness

- [x] Build passes
- [x] Health check
- [x] Logging
- [x] Rate limiting
- [x] Validation
- [x] Mobile responsive
- [x] Accessibility
- [x] Fictional data only
- [x] README, docs

Ready to deploy!
