# API Contract — InternBoard

Base URL: `/api`
Content-Type: `application/json`
All responses include `X-Request-Id`.

## Health
### GET /api/health
Returns system health.

**200 OK:**
```json
{
  "status": "healthy",
  "timestamp": "2026-05-11T...",
  "uptime": 123,
  "version": "1.0.0",
  "environment": "production",
  "requestId": "abc123",
  "checks": [
    {"name":"database","status":"ok","latencyMs":5},
    {"name":"memory","status":"ok"}
  ],
  "metrics": {"heapUsedMb":45,"heapTotalMb":80,"rssMb":120,"responseTimeMs":10}
}
```
**503** if any check fails.

---

## Internships

### GET /api/internships
Query params:
- `search` (string): title, company, description ilike
- `location` (string): location ilike
- `workType` (enum: remote|hybrid|onsite)
- `category` (string)
- `experience` (enum: entry|intermediate|advanced)
- `minStipend` (int)
- `isActive` (bool, default true)
- `page` (int, default 1)
- `limit` (int, default 12, max 50)
- `sort` (enum: newest|stipend_high|stipend_low|deadline)

**200:**
```json
{
  "data": [ { "id":"uuid", "title":"...", ... } ],
  "pagination": {"page":1,"limit":12,"total":24,"totalPages":2,"hasNext":true,"hasPrev":false}
}
```

### GET /api/internships/:id
**200:** `{ "data": {...} }`
**404:** `{ "error":"Internship not found" }`

### POST /api/internships
Body validated by `internshipSchema` (Zod).
Required: title (3-255), company (2-255), location (2-255), category, description (20+)
Optional: companyLogo (url), workType (enum default remote), skills (string[]), stipendMin/Max (int), durationMonths (1-24), deadline (ISO date), tags (string[]), experienceLevel, perks, applicationUrl

**201:** `{ "data": created }`
**400:** `{ "error":"Validation failed", "details":{...} }`
**429:** Rate limited

### PUT /api/internships/:id
Partial update, same schema .partial()

**200:** `{ "data": updated }`
**404** if not found

### DELETE /api/internships/:id
**200:** `{ "message":"Internship deleted", "data": deleted }`
**404** if not found

---

## Applications

### GET /api/applications
Query:
- `email` (string, ilike)
- `internshipId` (uuid)
- `status` (enum)

Returns enriched with internship title/company.

**200:** `{ "data": [ { "id":"...", "internshipId":"...", "fullName":"...", "status":"pending", "internship": {"title":"...", "company":"..."} } ] }`

### POST /api/applications
Body validated by `applicationSchema`:
- internshipId (uuid, required)
- fullName (2-255, required)
- email (email, required)
- phone (optional)
- university (optional)
- graduationYear (1900-2035, optional)
- resumeUrl (url optional)
- coverLetter (20-5000, required)
- portfolioUrl, linkedinUrl (url optional)

Logic:
- Check internship exists & isActive
- Prevent duplicate: same email + internshipId => 409
- Increment internships.applicantsCount
- Rate limited 60/min/IP

**201:** `{ "data": created, "message":"Application submitted successfully" }`
**400:** validation / inactive
**404:** internship not found
**409:** duplicate
**429:** rate limited

### PATCH /api/applications/:id
Body: `{ "status": "pending"|"reviewed"|"shortlisted"|"rejected"|"accepted" }`

**200:** `{ "data": updated }`
**400** validation, **404** not found

### DELETE /api/applications/:id
**200:** `{ "message":"Application deleted" }`

---

## Stats

### GET /api/stats
**200:**
```json
{
  "internships": {"total":12,"active":12,"remote":5,"totalApplicants":0},
  "applications": {"total":3,"pending":2,"shortlisted":1,"accepted":0},
  "categories": [{"category":"Software Engineering","count":4},...]
}
```

---

## Seed

### POST /api/seed
Seeds 12 fictional internships if count <=5, else returns already seeded.

**200:** `{ "message":"Seeded successfully", "count":12 }`

### GET /api/seed
Returns info: `{ "message":"Use POST to seed", "sampleCount":12 }`

---

## Error Format
```json
{ "error": "Human readable", "details": {} }
```

## Headers
- `X-Request-Id`: unique per request
- `Cache-Control`: public caching for GET
- `Retry-After`: on 429

## Security
- No auth for demo, but rate limited
- Validation via Zod prevents injection
- Drizzle param queries prevent SQL injection

## Logging
Each handler logs request method, path, status, duration, requestId.
