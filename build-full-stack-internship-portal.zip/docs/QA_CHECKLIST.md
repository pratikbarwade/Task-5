# QA Checklist — InternBoard

Use this as starter checklist, mark each as you finish (as per task screenshot).

## 1. Polish Complete User Journey and Mobile Experience

### User Journey
- [x] Homepage hero with value prop, stats, search
- [x] Search works with query param, shareable URL
- [x] Filters: workType, category, experience, sort, location
- [x] Listing pagination, empty state, loading
- [x] Detail page with breadcrumb, full info, apply CTA
- [x] Apply form: validation, success state, redirect to dashboard
- [x] Dashboard: view applications by email, status badges
- [x] Post internship: validation, success, redirect
- [x] Manage internships: list, delete with confirm
- [x] Stats API and display

### Mobile Experience
- [x] Header hamburger with aria-expanded, closes on nav
- [x] Search stacks vertical on <640px
- [x] Cards 1 col mobile, 2 tablet, 3 desktop
- [x] Forms full width mobile, touch targets >=44px
- [x] Tables horizontal scroll, not breaking layout
- [x] No horizontal scroll on any page
- [x] Fluid typography, responsive padding
- [x] Tested 375px, 768px, 1440px

## 2. Meaningful Logging, Health Checks, Useful README

### Logging
- [x] Structured JSON logger with timestamp, level, message, requestId
- [x] Request logging: method, path, status, duration
- [x] Info for normal ops, warn for rate limit/validation, error for DB failures
- [x] Logs in all API routes
- [x] No sensitive data in logs (no full PII)

### Health Checks
- [x] GET /api/health returns status, timestamp, uptime, version, checks, metrics
- [x] Checks DB SELECT 1 with latency
- [x] Checks memory heap <500MB
- [x] Returns 200 healthy or 503 degraded
- [x] Includes X-Request-Id header
- [x] Used for deployment healthcheck

### README
- [x] Title, objective, deliverable
- [x] Features list
- [x] Tech stack
- [x] Project structure
- [x] Quick start beginner-friendly
- [x] API contract summary
- [x] QA summary
- [x] Deployment guide link
- [x] Video plan link
- [x] Submission checklist

## 3. Accessibility, Performance, Security, Regression Checks

### Accessibility (WCAG AA)
- [x] Semantic HTML: header, nav, main, footer, article, section
- [x] Skip link
- [x] Keyboard navigation all interactive
- [x] Focus-visible ring
- [x] ARIA labels for nav, search, alerts
- [x] Form labels associated
- [x] Alt text for images
- [x] Color contrast >=4.5:1
- [x] Heading hierarchy
- [x] Touch targets >=44px
- [x] Audit doc: docs/ACCESSIBILITY_AUDIT.md

### Performance
- [x] Pagination limit 12, max 50
- [x] Caching headers s-maxage
- [x] Lazy images
- [x] No large JS bundles (~90kB)
- [x] RSC for server fetching
- [x] API latency <100ms
- [x] No layout shift (CLS 0)
- [x] Report: docs/PERFORMANCE_REPORT.md

### Security
- [x] Zod validation for all inputs
- [x] Drizzle param queries (SQLi safe)
- [x] Rate limiting 60/min
- [x] XSS prevention (no dangerouslySetInnerHTML)
- [x] No secrets in client
- [x] Generic 500 errors
- [x] Test SQLi, XSS, rate limit
- [x] Checklist: docs/SECURITY_CHECKLIST.md

### Regression
- [x] Critical flows tested: discover -> apply -> dashboard -> post -> delete
- [x] Edge cases: duplicate apply 409, inactive 400, invalid email 400
- [x] API curl tests
- [x] Build passes: typegen, tsc, build
- [x] Evidence: docs/TEST_EVIDENCE.md

## 4. Submission

- [x] One public/view-only link (GitHub repo)
- [x] All supporting files in same repo/folder
- [x] Fictional data only
- [x] Beginner-friendly
- [x] Production-ready
- [x] GitHub-ready
- [x] Docs folder with 8 docs
- [x] README useful
- [x] Video plan

## 5. Deployment Prep

- [x] .env.example
- [x] drizzle.config.json exists
- [x] package.json build scripts
- [x] next.config.ts
- [x] Health endpoint for platform
- [x] Seed endpoint for demo
- [x] Deployment doc: docs/DEPLOYMENT.md

## 6. Final Validation

- [x] npx next typegen -> PASS
- [x] npm exec tsc --noEmit -> PASS
- [x] npm run build -> PASS
- [x] build_and_start -> health ok

All checked!
