# Architecture — InternBoard

## Overview
InternBoard is a full-stack monolith using Next.js App Router where frontend and backend share same deployment. Chosen for beginner-friendliness and production readiness: single repo, single deploy, no CORS issues, file-based routing.

## Diagram
```
Browser -> Next.js App Router
  -> / (RSC) fetches DB via Drizzle -> renders
  -> /api/* -> logger -> rateLimit -> Zod -> Drizzle -> PostgreSQL
  -> /internships/[id] -> RSC + Client form
  -> /dashboard -> Client fetches /api/applications
```

## Data Model
- **internships**: id (uuid pk), title, company, companyLogo, location, workType (remote/hybrid/onsite), category, employmentType, description, responsibilities, requirements, skills (jsonb), stipendMin/Max, currency, durationMonths, deadline, postedAt, isActive, applicantsCount, tags (jsonb), experienceLevel, perks, applicationUrl, createdAt, updatedAt
- **applications**: id, internshipId (fk cascade), fullName, email, phone, university, graduationYear, resumeUrl, coverLetter, portfolioUrl, linkedinUrl, status (pending/reviewed/shortlisted/rejected/accepted), appliedAt, updatedAt

Indexes implicit via PK, FK. Future: add GIN index on skills/tags, btree on category, workType.

## API Layer
- **Validation**: Zod schemas in `src/lib/validators.ts` — single source of truth, returns 400 with flattened errors.
- **Logging**: `logger.ts` emits JSON with timestamp, level, requestId, path, duration. Request logging in each handler.
- **Rate Limiting**: In-memory Map with window 60s, max 60 req/IP/route. For distributed prod, swap to Redis (Upstash). Cleanup interval 5min.
- **Error Handling**: Try/catch, logger.error, return 500 generic to avoid leaking internals. 404 for not found, 409 for duplicate application, 429 for rate limit.

## Frontend Architecture
- **RSC for listing**: `/internships/page.tsx` is async Server Component fetching DB directly (fast, no extra hop) — but also API available for client filtering. SearchParams drives filters, enabling shareable URLs.
- **Client Components**: SearchBar, Filters use `useRouter` + `useSearchParams` to update URL, triggering RSC re-render (Next.js pattern).
- **ApplicationForm**: Client with local state, validation, fetch POST, localStorage email for UX.
- **Dashboard**: Client, fetches via API to demonstrate integration, uses email query param.
- **Components**: Pure, Tailwind, accessible.

## Performance Decisions
- Pagination limit 12, max 50 — prevents large payloads.
- Cache headers: `s-maxage=30, stale-while-revalidate=60` for list, 60s for stats.
- Images: native `<img>` with `loading="lazy"`, logo 100x100 via picsum placeholder. Could upgrade to Next/Image but kept simple for beginner.
- No heavy client libs — only React, Next, Zod.
- DB pooling: global pool singleton to avoid connection exhaustion in dev HMR.

## Security Decisions
- Drizzle ORM uses parameterized queries — no string interpolation.
- Zod strips unknown fields, validates email, URL, length.
- Rate limiting prevents brute force apply/post.
- `DATABASE_URL` server-only, never exposed via NEXT_PUBLIC.
- No `dangerouslySetInnerHTML` — prevents XSS. All user content rendered as text.
- Headers: X-Request-Id for tracing.

## Mobile-First
- Tailwind responsive: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Header: hidden md:flex for desktop nav, hamburger with aria-expanded for mobile.
- Touch targets: buttons min h-10 (40px), forms py-2.5.
- Tables: overflow-x-auto for small screens.

## Logging Strategy
- Info for normal operations (list, create)
- Warn for rate limit, not found, validation
- Error for DB failures
- Request log includes duration for performance monitoring
- In prod, pipe stdout to Datadog / Logtail.

## Health Check
`/api/health` checks DB SELECT 1, memory heap <500MB, returns 200 healthy or 503 degraded, includes metrics. Used by deployment platform.

## Future Improvements
- Auth via NextAuth for real recruiters
- File upload for resumes to S3
- Redis rate limiter
- Full-text search via Postgres tsvector
- Background jobs for email notifications
- Unit tests with Vitest, E2E with Playwright

## Why This Stack for Beginners?
- One language (TS) full-stack
- File-based routing intuitive
- Drizzle simple, SQL-like, type-safe
- Tailwind no CSS files to manage
- Vercel deploy 1-click
